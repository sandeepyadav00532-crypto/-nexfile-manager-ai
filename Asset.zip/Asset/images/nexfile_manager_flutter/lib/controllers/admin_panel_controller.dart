import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/admin_settings_model.dart';

/// AdminPanelController - Manages hidden admin panel with feature toggles
/// Entry: Long-press app logo 10 times on About screen + Master PIN (7848)
class AdminPanelController extends ChangeNotifier {
  final SharedPreferences _prefs;

  // Admin Panel State
  int _logoTapCount = 0;
  bool _isPINVerified = false;
  bool _isAdminPanelVisible = false;
  AdminSettings _adminSettings = AdminSettings();

  // Constants
  static const int REQUIRED_TAPS = 10;
  static const String MASTER_PIN = '7848';
  static const String ADMIN_SETTINGS_KEY = 'admin_settings';
  static const String PIN_VERIFIED_KEY = 'pin_verified';

  AdminPanelController(this._prefs) {
    _loadAdminSettings();
  }

  // Getters
  int get logoTapCount => _logoTapCount;
  bool get isPINVerified => _isPINVerified;
  bool get isAdminPanelVisible => _isAdminPanelVisible;
  AdminSettings get adminSettings => _adminSettings;

  /// Handle logo tap for admin entry
  void handleLogoTap() {
    _logoTapCount++;
    notifyListeners();

    // Reset tap count after 5 seconds
    Future.delayed(const Duration(seconds: 5), () {
      if (_logoTapCount > 0) {
        _logoTapCount = 0;
        notifyListeners();
      }
    });

    // Check if admin panel should open
    if (_logoTapCount >= REQUIRED_TAPS) {
      _showPINDialog();
    }
  }

  /// Show PIN verification dialog
  void _showPINDialog() {
    _logoTapCount = 0; // Reset tap count
    // This will be called from UI to show dialog
    notifyListeners();
  }

  /// Verify Master PIN
  bool verifyMasterPIN(String enteredPIN) {
    if (enteredPIN == MASTER_PIN) {
      _isPINVerified = true;
      _isAdminPanelVisible = true;
      _prefs.setBool(PIN_VERIFIED_KEY, true);
      notifyListeners();
      return true;
    }
    return false;
  }

  /// Close admin panel
  void closeAdminPanel() {
    _isAdminPanelVisible = false;
    _isPINVerified = false;
    _prefs.setBool(PIN_VERIFIED_KEY, false);
    notifyListeners();
  }

  /// Toggle feature on/off
  void toggleFeature(String featureName, bool enabled) {
    switch (featureName) {
      case 'vault':
        _adminSettings.isVaultEnabled = enabled;
        break;
      case 'videoTools':
        _adminSettings.isVideoToolsEnabled = enabled;
        break;
      case 'qrScanner':
        _adminSettings.isQRScannerEnabled = enabled;
        break;
      case 'cloudStorage':
        _adminSettings.isCloudStorageEnabled = enabled;
        break;
      case 'documentScanner':
        _adminSettings.isDocumentScannerEnabled = enabled;
        break;
      case 'pdfTools':
        _adminSettings.isPDFToolsEnabled = enabled;
        break;
      case 'imageTools':
        _adminSettings.isImageToolsEnabled = enabled;
        break;
      case 'cleanupEngine':
        _adminSettings.isCleanupEngineEnabled = enabled;
        break;
    }
    _saveAdminSettings();
    notifyListeners();
  }

  /// Change primary accent color
  void changePrimaryColor(String hexColor) {
    _adminSettings.primaryAccentColor = hexColor;
    _saveAdminSettings();
    notifyListeners();
  }

  /// Change encryption type
  void changeEncryptionType(String encryptionType) {
    _adminSettings.encryptionType = encryptionType; // 'AES-256' or 'ChaCha20'
    _saveAdminSettings();
    notifyListeners();
  }

  /// Set recently deleted retention days
  void setRetentionDays(int days) {
    _adminSettings.recentlyDeletedRetentionDays = days;
    _saveAdminSettings();
    notifyListeners();
  }

  /// Master reset - Wipe all app data
  Future<bool> performMasterReset() async {
    try {
      // Clear all shared preferences
      await _prefs.clear();

      // Reset admin settings to defaults
      _adminSettings = AdminSettings();
      _isPINVerified = false;
      _isAdminPanelVisible = false;
      _logoTapCount = 0;

      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('Master reset failed: $e');
      return false;
    }
  }

  /// Save admin settings to SharedPreferences
  void _saveAdminSettings() {
    _prefs.setString(ADMIN_SETTINGS_KEY, _adminSettings.toJson());
  }

  /// Load admin settings from SharedPreferences
  void _loadAdminSettings() {
    final settingsJson = _prefs.getString(ADMIN_SETTINGS_KEY);
    if (settingsJson != null) {
      _adminSettings = AdminSettings.fromJson(settingsJson);
    }

    _isPINVerified = _prefs.getBool(PIN_VERIFIED_KEY) ?? false;
  }

  /// Get all feature statuses
  Map<String, bool> getFeatureStatuses() {
    return {
      'vault': _adminSettings.isVaultEnabled,
      'videoTools': _adminSettings.isVideoToolsEnabled,
      'qrScanner': _adminSettings.isQRScannerEnabled,
      'cloudStorage': _adminSettings.isCloudStorageEnabled,
      'documentScanner': _adminSettings.isDocumentScannerEnabled,
      'pdfTools': _adminSettings.isPDFToolsEnabled,
      'imageTools': _adminSettings.isImageToolsEnabled,
      'cleanupEngine': _adminSettings.isCleanupEngineEnabled,
    };
  }

  /// Get current configuration
  Map<String, dynamic> getConfiguration() {
    return {
      'primaryAccentColor': _adminSettings.primaryAccentColor,
      'encryptionType': _adminSettings.encryptionType,
      'recentlyDeletedRetentionDays': _adminSettings.recentlyDeletedRetentionDays,
      'features': getFeatureStatuses(),
    };
  }
}
