import 'package:flutter/material.dart';

class ToolsScreen extends StatefulWidget {
  const ToolsScreen({Key? key}) : super(key: key);

  @override
  State<ToolsScreen> createState() => _ToolsScreenState();
}

class _ToolsScreenState extends State<ToolsScreen> {
  final List<Map<String, dynamic>> toolCategories = [
    {
      'name': 'PDF Tools',
      'icon': '📄',
      'tools': [
        {'name': 'Merge PDFs', 'icon': '📎'},
        {'name': 'Split PDF', 'icon': '✂️'},
        {'name': 'Compress PDF', 'icon': '📦'},
        {'name': 'Convert to PDF', 'icon': '🔄'},
      ],
    },
    {
      'name': 'Image Tools',
      'icon': '🖼️',
      'tools': [
        {'name': 'Compress Image', 'icon': '📉'},
        {'name': 'Resize Image', 'icon': '📐'},
        {'name': 'PNG to JPG', 'icon': '🔄'},
        {'name': 'Batch Convert', 'icon': '📦'},
      ],
    },
    {
      'name': 'Video Tools',
      'icon': '🎬',
      'tools': [
        {'name': 'Compress Video', 'icon': '📉'},
        {'name': 'Trim Video', 'icon': '✂️'},
        {'name': 'Convert Video', 'icon': '🔄'},
        {'name': 'Extract Audio', 'icon': '🎵'},
      ],
    },
    {
      'name': 'QR Tools',
      'icon': '📱',
      'tools': [
        {'name': 'QR Scanner', 'icon': '📸'},
        {'name': 'QR Generator', 'icon': '✨'},
        {'name': 'Batch Scan', 'icon': '📦'},
        {'name': 'QR History', 'icon': '📋'},
      ],
    },
    {
      'name': 'Document Scanner',
      'icon': '📋',
      'tools': [
        {'name': 'Scan Document', 'icon': '📸'},
        {'name': 'OCR Recognition', 'icon': '🔍'},
        {'name': 'Document to PDF', 'icon': '📄'},
        {'name': 'Batch Scan', 'icon': '📦'},
      ],
    },
    {
      'name': 'Cloud Storage',
      'icon': '☁️',
      'tools': [
        {'name': 'Google Drive', 'icon': '🔵'},
        {'name': 'OneDrive', 'icon': '🔷'},
        {'name': 'Dropbox', 'icon': '🔹'},
        {'name': 'Cloud Sync', 'icon': '🔄'},
      ],
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tools'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Available Tools',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 16),
              ...toolCategories.map((category) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Category header
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Row(
                        children: [
                          Text(
                            category['icon'],
                            style: const TextStyle(fontSize: 24),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            category['name'],
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                        ],
                      ),
                    ),

                    // Tools grid
                    GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 1.2,
                      children: (category['tools'] as List).map<Widget>((tool) {
                        return _buildToolCard(context, tool);
                      }).toList(),
                    ),
                    const SizedBox(height: 24),
                  ],
                );
              }).toList(),
            ],
          ),
        ),
      ),
    );
  }

  /// Build tool card
  Widget _buildToolCard(BuildContext context, Map<String, dynamic> tool) {
    return Card(
      child: InkWell(
        onTap: () => _handleToolTap(context, tool['name']),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              tool['icon'],
              style: const TextStyle(fontSize: 32),
            ),
            const SizedBox(height: 8),
            Text(
              tool['name'],
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  /// Handle tool tap
  void _handleToolTap(BuildContext context, String toolName) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Opening $toolName...'),
        duration: const Duration(seconds: 2),
      ),
    );

    // Navigate to tool screen based on tool name
    switch (toolName) {
      case 'QR Scanner':
        _openQRScanner(context);
        break;
      case 'QR Generator':
        _openQRGenerator(context);
        break;
      case 'Scan Document':
        _openDocumentScanner(context);
        break;
      case 'Compress Video':
        _openVideoCompressor(context);
        break;
      case 'Trim Video':
        _openVideoTrimmer(context);
        break;
      default:
        _showComingSoon(context, toolName);
    }
  }

  /// Open QR Scanner
  void _openQRScanner(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('QR Scanner'),
        content: const Text('Camera access required to scan QR codes'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('QR Scanner opened')),
              );
            },
            child: const Text('Open Camera'),
          ),
        ],
      ),
    );
  }

  /// Open QR Generator
  void _openQRGenerator(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Generate QR Code'),
        content: TextField(
          decoration: const InputDecoration(
            hintText: 'Enter text or URL',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('QR Code generated and saved')),
              );
            },
            child: const Text('Generate'),
          ),
        ],
      ),
    );
  }

  /// Open Document Scanner
  void _openDocumentScanner(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Document Scanner'),
        content: const Text('Camera access required to scan documents'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Document Scanner opened')),
              );
            },
            child: const Text('Open Camera'),
          ),
        ],
      ),
    );
  }

  /// Open Video Compressor
  void _openVideoCompressor(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Video Compressor'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Select compression quality:'),
            const SizedBox(height: 16),
            RadioListTile(
              title: const Text('High Quality (75%)'),
              value: 75,
              groupValue: 75,
              onChanged: (value) {},
            ),
            RadioListTile(
              title: const Text('Medium Quality (50%)'),
              value: 50,
              groupValue: 75,
              onChanged: (value) {},
            ),
            RadioListTile(
              title: const Text('Low Quality (25%)'),
              value: 25,
              groupValue: 75,
              onChanged: (value) {},
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Video compression started')),
              );
            },
            child: const Text('Compress'),
          ),
        ],
      ),
    );
  }

  /// Open Video Trimmer
  void _openVideoTrimmer(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Video Trimmer'),
        content: const Text('Select a video to trim'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Video Trimmer opened')),
              );
            },
            child: const Text('Select Video'),
          ),
        ],
      ),
    );
  }

  /// Show coming soon dialog
  void _showComingSoon(BuildContext context, String toolName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Coming Soon'),
        content: Text('$toolName will be available in the next update'),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}
