import 'dart:convert';

/// AdminSettings Model - Stores all admin panel configurations
class AdminSettings {
  // Feature toggles
  bool isVaultEnabled;
  bool isVideoToolsEnabled;
  bool isQRScannerEnabled;
  bool isCloudStorageEnabled;
  bool isDocumentScannerEnabled;
  bool isPDFToolsEnabled;
  bool isImageToolsEnabled;
  bool isCleanupEngineEnabled;

  // UI Customization
  String primaryAccentColor;

  // System Configuration
  String encryptionType; // 'AES-256' or 'ChaCha20'
  int recentlyDeletedRetentionDays;

  AdminSettings({
    this.isVaultEnabled = true,
    this.isVideoToolsEnabled = true,
    this.isQRScannerEnabled = true,
    this.isCloudStorageEnabled = true,
    this.isDocumentScannerEnabled = true,
    this.isPDFToolsEnabled = true,
    this.isImageToolsEnabled = true,
    this.isCleanupEngineEnabled = true,
    this.primaryAccentColor = '#10B981',
    this.encryptionType = 'AES-256',
    this.recentlyDeletedRetentionDays = 30,
  });

  /// Convert to JSON string
  String toJson() {
    return jsonEncode({
      'isVaultEnabled': isVaultEnabled,
      'isVideoToolsEnabled': isVideoToolsEnabled,
      'isQRScannerEnabled': isQRScannerEnabled,
      'isCloudStorageEnabled': isCloudStorageEnabled,
      'isDocumentScannerEnabled': isDocumentScannerEnabled,
      'isPDFToolsEnabled': isPDFToolsEnabled,
      'isImageToolsEnabled': isImageToolsEnabled,
      'isCleanupEngineEnabled': isCleanupEngineEnabled,
      'primaryAccentColor': primaryAccentColor,
      'encryptionType': encryptionType,
      'recentlyDeletedRetentionDays': recentlyDeletedRetentionDays,
    });
  }

  /// Create from JSON string
  factory AdminSettings.fromJson(String jsonString) {
    final json = jsonDecode(jsonString) as Map<String, dynamic>;
    return AdminSettings(
      isVaultEnabled: json['isVaultEnabled'] ?? true,
      isVideoToolsEnabled: json['isVideoToolsEnabled'] ?? true,
      isQRScannerEnabled: json['isQRScannerEnabled'] ?? true,
      isCloudStorageEnabled: json['isCloudStorageEnabled'] ?? true,
      isDocumentScannerEnabled: json['isDocumentScannerEnabled'] ?? true,
      isPDFToolsEnabled: json['isPDFToolsEnabled'] ?? true,
      isImageToolsEnabled: json['isImageToolsEnabled'] ?? true,
      isCleanupEngineEnabled: json['isCleanupEngineEnabled'] ?? true,
      primaryAccentColor: json['primaryAccentColor'] ?? '#10B981',
      encryptionType: json['encryptionType'] ?? 'AES-256',
      recentlyDeletedRetentionDays: json['recentlyDeletedRetentionDays'] ?? 30,
    );
  }
}
