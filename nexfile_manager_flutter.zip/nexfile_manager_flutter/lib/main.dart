import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';

// Services
import 'services/file_service.dart';
import 'services/storage_service.dart';
import 'services/admin_service.dart';
import 'services/database_service.dart';
import 'services/permission_service.dart';
import 'services/theme_service.dart';
import 'services/localization_service.dart';

// Providers
import 'providers/theme_provider.dart';
import 'providers/file_provider.dart';
import 'providers/storage_provider.dart';
import 'providers/admin_provider.dart';
import 'providers/settings_provider.dart';

// Screens
import 'screens/splash_screen.dart';
import 'screens/home_screen.dart';
import 'screens/storage_screen.dart';
import 'screens/tools_screen.dart';
import 'screens/vault_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/admin_panel_screen.dart';
import 'screens/permission_required_screen.dart';

// Firebase Configuration
import 'firebase_options.dart';

// Global Service Locator
final getIt = GetIt.instance;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Setup Firebase Crashlytics
  if (!kDebugMode) {
    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;
    PlatformDispatcher.instance.onError = (error, stack) {
      FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
      return true;
    };
  }

  // Initialize Hive for local storage
  await Hive.initFlutter();

  // Initialize SharedPreferences
  final prefs = await SharedPreferences.getInstance();

  // Setup Service Locator (Dependency Injection)
  await _setupServiceLocator(prefs);

  // Initialize Permission Service
  await getIt<PermissionService>().requestInitialPermissions();

  // Initialize Database
  await getIt<DatabaseService>().initializeDatabase();

  // Initialize Theme Service
  await getIt<ThemeService>().loadTheme();

  // Initialize Localization Service
  await getIt<LocalizationService>().loadLocale();

  runApp(
    MultiProvider(
      providers: [
        // Theme Provider
        ChangeNotifierProvider(
          create: (_) => ThemeProvider(getIt<ThemeService>()),
        ),
        // File Provider
        ChangeNotifierProvider(
          create: (_) => FileProvider(getIt<FileService>()),
        ),
        // Storage Provider
        ChangeNotifierProvider(
          create: (_) => StorageProvider(getIt<StorageService>()),
        ),
        // Admin Provider
        ChangeNotifierProvider(
          create: (_) => AdminProvider(getIt<AdminService>()),
        ),
        // Settings Provider
        ChangeNotifierProvider(
          create: (_) => SettingsProvider(
            getIt<ThemeService>(),
            getIt<LocalizationService>(),
          ),
        ),
      ],
      child: const NexFileManagerApp(),
    ),
  );
}

/// Setup Service Locator for Dependency Injection
Future<void> _setupServiceLocator(SharedPreferences prefs) async {
  // Register SharedPreferences
  getIt.registerSingleton<SharedPreferences>(prefs);

  // Register Firebase Analytics
  getIt.registerSingleton<FirebaseAnalytics>(FirebaseAnalytics.instance);

  // Register Firebase Crashlytics
  getIt.registerSingleton<FirebaseCrashlytics>(FirebaseCrashlytics.instance);

  // Register Services
  getIt.registerSingleton<PermissionService>(PermissionService());
  getIt.registerSingleton<DatabaseService>(DatabaseService(prefs));
  getIt.registerSingleton<FileService>(FileService(getIt<DatabaseService>()));
  getIt.registerSingleton<StorageService>(StorageService(getIt<FileService>()));
  getIt.registerSingleton<AdminService>(AdminService(prefs));
  getIt.registerSingleton<ThemeService>(ThemeService(prefs));
  getIt.registerSingleton<LocalizationService>(LocalizationService(prefs));
}

class NexFileManagerApp extends StatefulWidget {
  const NexFileManagerApp({Key? key}) : super(key: key);

  @override
  State<NexFileManagerApp> createState() => _NexFileManagerAppState();
}

class _NexFileManagerAppState extends State<NexFileManagerApp> {
  late FirebaseAnalytics _analytics;
  late FirebaseAnalyticsObserver _observer;

  @override
  void initState() {
    super.initState();
    _analytics = FirebaseAnalytics.instance;
    _observer = FirebaseAnalyticsObserver(analytics: _analytics);

    // Log app launch
    _analytics.logAppOpen();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, _) {
        return MaterialApp(
          title: 'NexFile Manager AI',
          debugShowCheckedModeBanner: false,

          // Theme Configuration
          theme: _buildLightTheme(),
          darkTheme: _buildDarkTheme(),
          themeMode: themeProvider.themeMode,

          // Localization
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: const [
            Locale('en', ''),
            Locale('hi', ''),
            Locale('mr', ''),
            Locale('gu', ''),
            Locale('ta', ''),
            Locale('te', ''),
            Locale('kn', ''),
            Locale('bn', ''),
          ],
          locale: Locale(getIt<LocalizationService>().currentLocale),

          // Analytics Observer
          navigatorObservers: [_observer],

          // Home Screen
          home: const SplashScreen(),

          // Named Routes
          routes: {
            '/home': (context) => const HomeScreen(),
            '/storage': (context) => const StorageScreen(),
            '/tools': (context) => const ToolsScreen(),
            '/vault': (context) => const VaultScreen(),
            '/settings': (context) => const SettingsScreen(),
            '/admin': (context) => const AdminPanelScreen(),
            '/permission_required': (context) => const PermissionRequiredScreen(),
          },
        );
      },
    );
  }

  /// Build Light Theme
  ThemeData _buildLightTheme() {
    const Color primaryColor = Color(0xFF10B981); // Emerald Green
    const Color accentColor = Color(0xFF06B6D4); // Cyan
    const Color backgroundColor = Color(0xFFFFFFFF);
    const Color surfaceColor = Color(0xFFF5F5F5);

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      primaryColor: primaryColor,
      scaffoldBackgroundColor: backgroundColor,
      appBarTheme: const AppBarTheme(
        backgroundColor: backgroundColor,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: Color(0xFF11181C)),
        titleTextStyle: TextStyle(
          color: Color(0xFF11181C),
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      colorScheme: ColorScheme.light(
        primary: primaryColor,
        secondary: accentColor,
        surface: surfaceColor,
        background: backgroundColor,
        error: const Color(0xFFEF4444),
      ),
      cardTheme: CardTheme(
        color: surfaceColor,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surfaceColor,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: primaryColor, width: 2),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: backgroundColor,
        selectedItemColor: primaryColor,
        unselectedItemColor: Color(0xFF9BA1A6),
        elevation: 8,
      ),
    );
  }

  /// Build Dark Theme
  ThemeData _buildDarkTheme() {
    const Color primaryColor = Color(0xFF10B981); // Emerald Green
    const Color accentColor = Color(0xFF06B6D4); // Cyan
    const Color backgroundColor = Color(0xFF0A0A0A); // AMOLED Black
    const Color surfaceColor = Color(0xFF1A1A1A);

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      primaryColor: primaryColor,
      scaffoldBackgroundColor: backgroundColor,
      appBarTheme: const AppBarTheme(
        backgroundColor: surfaceColor,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: Color(0xFFECEDEE)),
        titleTextStyle: TextStyle(
          color: Color(0xFFECEDEE),
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      colorScheme: ColorScheme.dark(
        primary: primaryColor,
        secondary: accentColor,
        surface: surfaceColor,
        background: backgroundColor,
        error: const Color(0xFFF87171),
      ),
      cardTheme: CardTheme(
        color: surfaceColor,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: backgroundColor,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surfaceColor,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF334155)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF334155)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: primaryColor, width: 2),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: surfaceColor,
        selectedItemColor: primaryColor,
        unselectedItemColor: Color(0xFF9BA1A6),
        elevation: 8,
      ),
    );
  }
}
