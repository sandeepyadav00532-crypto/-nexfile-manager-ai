import 'package:flutter/material.dart';

class StorageStatusBar extends StatelessWidget {
  final int usedStorage;
  final int totalStorage;
  final double usagePercentage;

  const StorageStatusBar({
    Key? key,
    required this.usedStorage,
    required this.totalStorage,
    required this.usagePercentage,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Storage Status',
                  style: Theme.of(context).textTheme.titleSmall,
                ),
                Text(
                  '${usagePercentage.toStringAsFixed(1)}%',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color: _getStorageColor(),
                      ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: usagePercentage / 100,
                minHeight: 10,
                backgroundColor: Colors.grey[300],
                valueColor: AlwaysStoppedAnimation<Color>(_getStorageColor()),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              '${_formatBytes(usedStorage)} / ${_formatBytes(totalStorage)}',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.grey,
                  ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getStorageColor() {
    if (usagePercentage < 50) return Colors.green;
    if (usagePercentage < 75) return Colors.orange;
    if (usagePercentage < 90) return Colors.deepOrange;
    return Colors.red;
  }

  String _formatBytes(int bytes) {
    if (bytes <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB"];
    var i = (bytes.toString().length / 3).floor();
    var r = (bytes / _pow(1024, i)).toStringAsFixed(2);
    return '$r ${suffixes[i]}';
  }

  static num _pow(num x, num y) {
    return x * (y > 1 ? _pow(x, y - 1) : 1);
  }
}
