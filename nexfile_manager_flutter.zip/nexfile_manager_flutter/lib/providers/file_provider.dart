import 'package:flutter/foundation.dart';
import '../models/file_model.dart';

class FileProvider extends ChangeNotifier {
  List<FileModel> _allFiles = [];
  List<FileModel> _recentFiles = [];
  List<FileModel> _starredFiles = [];
  List<FileModel> _favoriteFiles = [];
  bool _isLoading = false;
  String? _error;

  // Getters
  List<FileModel> get allFiles => _allFiles;
  List<FileModel> get recentFiles => _recentFiles;
  List<FileModel> get starredFiles => _starredFiles;
  List<FileModel> get favoriteFiles => _favoriteFiles;
  bool get isLoading => _isLoading;
  String? get error => _error;

  /// Load all files
  Future<void> loadAllFiles() async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      // Simulate loading files
      await Future.delayed(const Duration(seconds: 1));

      _allFiles = [
        FileModel(
          id: '1',
          name: 'Document.pdf',
          path: '/storage/emulated/0/Documents/Document.pdf',
          size: 2048576,
          mimeType: 'application/pdf',
          category: 'Documents',
          lastModified: DateTime.now(),
        ),
        FileModel(
          id: '2',
          name: 'Photo.jpg',
          path: '/storage/emulated/0/Pictures/Photo.jpg',
          size: 3145728,
          mimeType: 'image/jpeg',
          category: 'Images',
          lastModified: DateTime.now(),
        ),
      ];

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Load recent files
  Future<void> loadRecentFiles() async {
    try {
      _isLoading = true;
      notifyListeners();

      await Future.delayed(const Duration(milliseconds: 500));

      _recentFiles = _allFiles.take(10).toList();

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Toggle star on file
  void toggleStar(String fileId) {
    final index = _allFiles.indexWhere((f) => f.id == fileId);
    if (index != -1) {
      _allFiles[index].isStarred = !_allFiles[index].isStarred;
      notifyListeners();
    }
  }

  /// Toggle favorite on file
  void toggleFavorite(String fileId) {
    final index = _allFiles.indexWhere((f) => f.id == fileId);
    if (index != -1) {
      _allFiles[index].isFavorite = !_allFiles[index].isFavorite;
      notifyListeners();
    }
  }

  /// Search files
  Future<List<FileModel>> searchFiles(String query) async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));

      return _allFiles
          .where((f) => f.name.toLowerCase().contains(query.toLowerCase()))
          .toList();
    } catch (e) {
      _error = e.toString();
      return [];
    }
  }

  /// Get files by category
  List<FileModel> getFilesByCategory(String category) {
    return _allFiles.where((f) => f.category == category).toList();
  }

  /// Clear error
  void clearError() {
    _error = null;
    notifyListeners();
  }
}
