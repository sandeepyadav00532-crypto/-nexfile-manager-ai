import 'package:flutter/foundation.dart';
import '../models/storage_stats_model.dart';

class StorageProvider extends ChangeNotifier {
  StorageStats _storageStats = StorageStats();
  bool _isLoading = false;
  String? _error;

  // Getters
  StorageStats get storageStats => _storageStats;
  bool get isLoading => _isLoading;
  String? get error => _error;

  /// Initialize storage stats
  Future<void> initializeStorage() async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      // Simulate loading storage stats
      await Future.delayed(const Duration(seconds: 1));

      _storageStats = StorageStats(
        totalStorage: 107374182400, // 100 GB
        usedStorage: 68719476736, // 64 GB
        freeStorage: 38654705664, // 36 GB
        usagePercentage: 64.0,
      );

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Refresh storage stats
  Future<void> refreshStorageStats() async {
    await initializeStorage();
  }

  /// Clear error
  void clearError() {
    _error = null;
    notifyListeners();
  }
}
