/// StorageStats Model - Represents device storage statistics
class StorageStats {
  final int totalStorage;
  final int usedStorage;
  final int freeStorage;
  final double usagePercentage;

  StorageStats({
    this.totalStorage = 0,
    this.usedStorage = 0,
    this.freeStorage = 0,
    this.usagePercentage = 0.0,
  });

  /// Create from JSON
  factory StorageStats.fromJson(Map<String, dynamic> json) {
    return StorageStats(
      totalStorage: json['totalStorage'] ?? 0,
      usedStorage: json['usedStorage'] ?? 0,
      freeStorage: json['freeStorage'] ?? 0,
      usagePercentage: (json['usagePercentage'] as num?)?.toDouble() ?? 0.0,
    );
  }

  /// Convert to JSON
  Map<String, dynamic> toJson() {
    return {
      'totalStorage': totalStorage,
      'usedStorage': usedStorage,
      'freeStorage': freeStorage,
      'usagePercentage': usagePercentage,
    };
  }

  /// Get human-readable storage info
  String getStorageInfo() {
    return '${_formatBytes(usedStorage)} / ${_formatBytes(totalStorage)}';
  }

  /// Helper: Format bytes to human-readable
  static String _formatBytes(int bytes) {
    if (bytes <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB"];
    var i = (bytes.toString().length / 3).floor();
    var r = (bytes / _pow(1024, i)).toStringAsFixed(2);
    return '$r ${suffixes[i]}';
  }

  static num _pow(num x, num y) {
    return x * (y > 1 ? _pow(x, y - 1) : 1);
  }
}
