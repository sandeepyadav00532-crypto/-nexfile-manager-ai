/// VaultFile Model - Represents encrypted files in the vault
class VaultFile {
  final String id;
  final String originalName;
  final String encryptedPath;
  final String originalPath;
  final int size;
  final DateTime addedDate;
  final String mimeType;

  VaultFile({
    required this.id,
    required this.originalName,
    required this.encryptedPath,
    required this.originalPath,
    required this.size,
    required this.addedDate,
    required this.mimeType,
  });

  /// Create from JSON
  factory VaultFile.fromJson(Map<String, dynamic> json) {
    return VaultFile(
      id: json['id'] ?? '',
      originalName: json['originalName'] ?? '',
      encryptedPath: json['encryptedPath'] ?? '',
      originalPath: json['originalPath'] ?? '',
      size: json['size'] ?? 0,
      addedDate: DateTime.parse(json['addedDate'] ?? DateTime.now().toIso8601String()),
      mimeType: json['mimeType'] ?? 'application/octet-stream',
    );
  }

  /// Convert to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'originalName': originalName,
      'encryptedPath': encryptedPath,
      'originalPath': originalPath,
      'size': size,
      'addedDate': addedDate.toIso8601String(),
      'mimeType': mimeType,
    };
  }

  /// Get file extension
  String getExtension() {
    final parts = originalName.split('.');
    return parts.length > 1 ? '.${parts.last}' : '';
  }

  /// Get file type category
  String getFileType() {
    if (mimeType.startsWith('image/')) return 'Image';
    if (mimeType.startsWith('video/')) return 'Video';
    if (mimeType.startsWith('audio/')) return 'Audio';
    if (mimeType.contains('pdf')) return 'PDF';
    if (mimeType.contains('document') || mimeType.contains('word')) return 'Document';
    return 'File';
  }

  /// Format file size
  String getFormattedSize() {
    if (size <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB"];
    var i = (size.toString().length / 3).floor();
    var r = (size / _pow(1024, i)).toStringAsFixed(2);
    return '$r ${suffixes[i]}';
  }

  static num _pow(num x, num y) {
    return x * (y > 1 ? _pow(x, y - 1) : 1);
  }
}
