/// FileModel - Represents a file in the system
class FileModel {
  final String id;
  final String name;
  final String path;
  final int size;
  final String mimeType;
  final String category;
  final DateTime lastModified;
  bool isStarred;
  bool isFavorite;
  bool isInVault;

  FileModel({
    required this.id,
    required this.name,
    required this.path,
    required this.size,
    required this.mimeType,
    required this.category,
    required this.lastModified,
    this.isStarred = false,
    this.isFavorite = false,
    this.isInVault = false,
  });

  /// Create from JSON
  factory FileModel.fromJson(Map<String, dynamic> json) {
    return FileModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      path: json['path'] ?? '',
      size: json['size'] ?? 0,
      mimeType: json['mimeType'] ?? 'application/octet-stream',
      category: json['category'] ?? 'Other',
      lastModified: DateTime.parse(json['lastModified'] ?? DateTime.now().toIso8601String()),
      isStarred: json['isStarred'] == 1,
      isFavorite: json['isFavorite'] == 1,
      isInVault: json['isInVault'] == 1,
    );
  }

  /// Convert to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'path': path,
      'size': size,
      'mimeType': mimeType,
      'category': category,
      'lastModified': lastModified.toIso8601String(),
      'isStarred': isStarred ? 1 : 0,
      'isFavorite': isFavorite ? 1 : 0,
      'isInVault': isInVault ? 1 : 0,
    };
  }

  /// Get file extension
  String getExtension() {
    final parts = name.split('.');
    return parts.length > 1 ? '.${parts.last}' : '';
  }

  /// Get file type icon
  String getFileTypeIcon() {
    if (mimeType.startsWith('image/')) return '🖼️';
    if (mimeType.startsWith('video/')) return '🎬';
    if (mimeType.startsWith('audio/')) return '🎵';
    if (mimeType.contains('pdf')) return '📄';
    if (mimeType.contains('document') || mimeType.contains('word')) return '📝';
    if (mimeType.contains('archive') || mimeType.contains('zip')) return '📦';
    if (mimeType.contains('android')) return '📱';
    return '📁';
  }

  /// Format file size
  String getFormattedSize() {
    if (size <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB"];
    var i = (size.toString().length / 3).floor();
    var r = (size / _pow(1024, i)).toStringAsFixed(2);
    return '$r ${suffixes[i]}';
  }

  /// Get formatted last modified date
  String getFormattedDate() {
    final now = DateTime.now();
    final difference = now.difference(lastModified);

    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else if (difference.inDays < 30) {
      return '${(difference.inDays / 7).floor()} weeks ago';
    } else if (difference.inDays < 365) {
      return '${(difference.inDays / 30).floor()} months ago';
    } else {
      return '${(difference.inDays / 365).floor()} years ago';
    }
  }

  /// Check if file is image
  bool get isImage => mimeType.startsWith('image/');

  /// Check if file is video
  bool get isVideo => mimeType.startsWith('video/');

  /// Check if file is audio
  bool get isAudio => mimeType.startsWith('audio/');

  /// Check if file is document
  bool get isDocument => mimeType.contains('document') || mimeType.contains('word') || mimeType.contains('pdf');

  static num _pow(num x, num y) {
    return x * (y > 1 ? _pow(x, y - 1) : 1);
  }
}
