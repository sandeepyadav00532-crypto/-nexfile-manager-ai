import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:storage_details/storage_details.dart';
import '../models/storage_stats_model.dart';

/// StorageController - Manages device storage statistics and analytics
class StorageController extends ChangeNotifier {
  StorageStats _storageStats = StorageStats();
  bool _isLoading = false;
  String? _error;

  // Category storage breakdown
  final Map<String, int> _categoryStorage = {
    'Images': 0,
    'Videos': 0,
    'Audio': 0,
    'Documents': 0,
    'Apps': 0,
    'Other': 0,
  };

  // Getters
  StorageStats get storageStats => _storageStats;
  bool get isLoading => _isLoading;
  String? get error => _error;
  Map<String, int> get categoryStorage => _categoryStorage;

  /// Initialize and fetch storage stats
  Future<void> initializeStorage() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Get storage details
      final storageDetails = await StorageDetails.storageDetails;

      if (storageDetails != null) {
        _storageStats = StorageStats(
          totalStorage: storageDetails.totalStorage ?? 0,
          usedStorage: storageDetails.usedStorage ?? 0,
          freeStorage: (storageDetails.totalStorage ?? 0) - (storageDetails.usedStorage ?? 0),
          usagePercentage: _calculatePercentage(
            storageDetails.usedStorage ?? 0,
            storageDetails.totalStorage ?? 0,
          ),
        );
      } else {
        // Fallback: Manual calculation
        await _calculateStorageManually();
      }

      // Calculate category breakdown
      await _calculateCategoryStorage();

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = 'Failed to fetch storage stats: $e';
      _isLoading = false;
      debugPrint('Storage error: $e');
      notifyListeners();
    }
  }

  /// Calculate storage manually (fallback)
  Future<void> _calculateStorageManually() async {
    try {
      final rootDir = Directory('/storage/emulated/0');
      int totalSize = 0;

      if (await rootDir.exists()) {
        final entities = rootDir.listSync(recursive: true, followLinks: false);
        for (final entity in entities) {
          if (entity is File) {
            totalSize += await entity.length();
          }
        }
      }

      // Estimate total storage (typically 64GB, 128GB, 256GB, etc.)
      int estimatedTotal = 64 * 1024 * 1024 * 1024; // 64GB default
      if (totalSize > 128 * 1024 * 1024 * 1024) {
        estimatedTotal = 256 * 1024 * 1024 * 1024; // 256GB
      } else if (totalSize > 64 * 1024 * 1024 * 1024) {
        estimatedTotal = 128 * 1024 * 1024 * 1024; // 128GB
      }

      _storageStats = StorageStats(
        totalStorage: estimatedTotal,
        usedStorage: totalSize,
        freeStorage: estimatedTotal - totalSize,
        usagePercentage: _calculatePercentage(totalSize, estimatedTotal),
      );
    } catch (e) {
      debugPrint('Manual storage calculation error: $e');
    }
  }

  /// Calculate storage breakdown by category
  Future<void> _calculateCategoryStorage() async {
    try {
      _categoryStorage['Images'] = await _getDirectorySize('/storage/emulated/0/DCIM') +
          await _getDirectorySize('/storage/emulated/0/Pictures');

      _categoryStorage['Videos'] = await _getDirectorySize('/storage/emulated/0/Movies') +
          await _getDirectorySize('/storage/emulated/0/DCIM');

      _categoryStorage['Audio'] = await _getDirectorySize('/storage/emulated/0/Music');

      _categoryStorage['Documents'] = await _getDirectorySize('/storage/emulated/0/Documents');

      _categoryStorage['Apps'] = await _getDirectorySize('/data/app') +
          await _getDirectorySize('/data/data');

      // Calculate Other
      int totalCategorized = _categoryStorage.values.fold(0, (a, b) => a + b);
      _categoryStorage['Other'] = (_storageStats.usedStorage - totalCategorized).abs();

      notifyListeners();
    } catch (e) {
      debugPrint('Error calculating category storage: $e');
    }
  }

  /// Get directory size recursively
  Future<int> _getDirectorySize(String dirPath) async {
    try {
      final dir = Directory(dirPath);
      if (!await dir.exists()) {
        return 0;
      }

      int size = 0;
      final entities = dir.listSync(recursive: true, followLinks: false);

      for (final entity in entities) {
        if (entity is File) {
          size += await entity.length();
        }
      }

      return size;
    } catch (e) {
      debugPrint('Error getting directory size for $dirPath: $e');
      return 0;
    }
  }

  /// Calculate percentage
  double _calculatePercentage(int used, int total) {
    if (total == 0) return 0;
    return (used / total) * 100;
  }

  /// Get category percentage
  double getCategoryPercentage(String category) {
    if (_storageStats.usedStorage == 0) return 0;
    return (_categoryStorage[category] ?? 0) / _storageStats.usedStorage * 100;
  }

  /// Format bytes to human-readable string
  static String formatBytes(int bytes) {
    if (bytes <= 0) return "0 B";

    const suffixes = ["B", "KB", "MB", "GB", "TB"];
    var i = (bytes.toString().length / 3).floor();
    var r = (bytes / pow(1024, i)).toStringAsFixed(2);

    return '$r ${suffixes[i]}';
  }

  /// Get storage status message
  String getStorageStatusMessage() {
    final usedPercent = _storageStats.usagePercentage;

    if (usedPercent < 50) {
      return 'Plenty of storage available';
    } else if (usedPercent < 75) {
      return 'Storage usage is moderate';
    } else if (usedPercent < 90) {
      return 'Storage is getting full';
    } else {
      return 'Storage is critically low';
    }
  }

  /// Get storage color based on usage
  String getStorageColorStatus() {
    final usedPercent = _storageStats.usagePercentage;

    if (usedPercent < 50) {
      return 'green'; // #10B981
    } else if (usedPercent < 75) {
      return 'yellow'; // #F59E0B
    } else if (usedPercent < 90) {
      return 'orange'; // #FF8C00
    } else {
      return 'red'; // #EF4444
    }
  }

  /// Refresh storage stats
  Future<void> refreshStorageStats() async {
    await initializeStorage();
  }

  /// Get large files (files > 50MB)
  Future<List<File>> getLargeFiles({int minSizeMB = 50}) async {
    final largeFiles = <File>[];
    final minSizeBytes = minSizeMB * 1024 * 1024;

    try {
      final rootDir = Directory('/storage/emulated/0');
      if (await rootDir.exists()) {
        final entities = rootDir.listSync(recursive: true, followLinks: false);

        for (final entity in entities) {
          if (entity is File) {
            final size = await entity.length();
            if (size > minSizeBytes) {
              largeFiles.add(entity);
            }
          }
        }
      }

      // Sort by size descending
      largeFiles.sort((a, b) => b.lengthSync().compareTo(a.lengthSync()));
    } catch (e) {
      debugPrint('Error getting large files: $e');
    }

    return largeFiles;
  }

  /// Get duplicate files (same size and name)
  Future<Map<String, List<File>>> getDuplicateFiles() async {
    final duplicates = <String, List<File>>{};
    final fileMap = <String, List<File>>{};

    try {
      final rootDir = Directory('/storage/emulated/0');
      if (await rootDir.exists()) {
        final entities = rootDir.listSync(recursive: true, followLinks: false);

        for (final entity in entities) {
          if (entity is File) {
            final fileName = entity.path.split('/').last;
            final fileSize = await entity.length();
            final key = '$fileName-$fileSize';

            if (fileMap.containsKey(key)) {
              fileMap[key]!.add(entity);
            } else {
              fileMap[key] = [entity];
            }
          }
        }

        // Filter to only duplicates
        fileMap.forEach((key, files) {
          if (files.length > 1) {
            duplicates[key] = files;
          }
        });
      }
    } catch (e) {
      debugPrint('Error getting duplicate files: $e');
    }

    return duplicates;
  }

  /// Get cache files
  Future<int> getCacheSize() async {
    try {
      final cacheDir = Directory('/data/cache');
      if (await cacheDir.exists()) {
        return await _getDirectorySize(cacheDir.path);
      }
      return 0;
    } catch (e) {
      debugPrint('Error getting cache size: $e');
      return 0;
    }
  }

  /// Clear cache files
  Future<bool> clearCache() async {
    try {
      final cacheDir = Directory('/data/cache');
      if (await cacheDir.exists()) {
        final entities = cacheDir.listSync(recursive: true);
        for (final entity in entities) {
          if (entity is File) {
            await entity.delete();
          }
        }
        await refreshStorageStats();
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Error clearing cache: $e');
      return false;
    }
  }

  /// Get temporary files
  Future<int> getTempFileSize() async {
    try {
      final tempDir = Directory('/data/local/tmp');
      if (await tempDir.exists()) {
        return await _getDirectorySize(tempDir.path);
      }
      return 0;
    } catch (e) {
      debugPrint('Error getting temp file size: $e');
      return 0;
    }
  }

  /// Clear temporary files
  Future<bool> clearTempFiles() async {
    try {
      final tempDir = Directory('/data/local/tmp');
      if (await tempDir.exists()) {
        final entities = tempDir.listSync(recursive: true);
        for (final entity in entities) {
          if (entity is File) {
            await entity.delete();
          }
        }
        await refreshStorageStats();
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Error clearing temp files: $e');
      return false;
    }
  }
}

/// Helper function for pow calculation
num pow(num x, num y) {
  return x * (y > 1 ? pow(x, y - 1) : 1);
}
