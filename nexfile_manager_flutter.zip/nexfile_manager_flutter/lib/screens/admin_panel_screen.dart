import 'package:flutter/material.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({Key? key}) : super(key: key);

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  bool _isAuthenticated = false;
  String _primaryColor = '#10B981';
  String _encryptionType = 'AES-256';
  int _retentionDays = 30;

  // Feature toggles
  bool _vaultEnabled = true;
  bool _videoToolsEnabled = true;
  bool _qrScannerEnabled = true;
  bool _documentScannerEnabled = true;
  bool _pdfToolsEnabled = true;
  bool _imageToolsEnabled = true;
  bool _cleanupEngineEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel (GOD MODE)'),
        elevation: 0,
        backgroundColor: Colors.red.withOpacity(0.1),
      ),
      body: !_isAuthenticated ? _buildAuthScreen() : _buildAdminPanel(),
    );
  }

  /// Build authentication screen
  Widget _buildAuthScreen() {
    final pinController = TextEditingController();

    return Center(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Warning icon
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(40),
                ),
                child: const Icon(
                  Icons.admin_panel_settings,
                  size: 40,
                  color: Colors.red,
                ),
              ),
              const SizedBox(height: 24),

              // Title
              Text(
                'Admin Panel',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              Text(
                'Enter Master PIN to access admin settings',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.grey,
                    ),
              ),
              const SizedBox(height: 32),

              // PIN input
              TextField(
                controller: pinController,
                obscureText: true,
                keyboardType: TextInputType.number,
                maxLength: 4,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 24, letterSpacing: 8),
                decoration: InputDecoration(
                  hintText: '••••',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  counterText: '',
                ),
              ),
              const SizedBox(height: 24),

              // Unlock button
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                  backgroundColor: Colors.red,
                ),
                onPressed: () {
                  if (pinController.text == '7848') {
                    setState(() => _isAuthenticated = true);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Admin panel unlocked')),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Incorrect PIN'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                },
                child: const Text('Unlock Admin Panel'),
              ),
              const SizedBox(height: 16),

              // Back button
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Back'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Build admin panel
  Widget _buildAdminPanel() {
    return SingleChildScrollView(
      child: Column(
        children: [
          // Premium Welcome Header with Owner Profile
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).primaryColor,
                  Theme.of(context).primaryColor.withOpacity(0.7),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    // Owner Profile Image
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 10,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/images/owner_profile.png',
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              color: Colors.white.withOpacity(0.2),
                              child: const Icon(
                                Icons.person,
                                color: Colors.white,
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Welcome Back,',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: Colors.white.withOpacity(0.9),
                                ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Owner Sandeep Yadav',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '🔐 GOD MODE ACTIVATED',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ),
              ],
            ),
          ),

          // Admin warning banner
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.red.withOpacity(0.1),
            child: Row(
              children: [
                const Icon(Icons.warning, color: Colors.red),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'You are in admin mode. Proceed with caution!',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ),
              ],
            ),
          ),

          // Feature Toggles
          _buildSectionHeader('Feature Toggles', context),
          _buildFeatureToggle('Vault', _vaultEnabled, (value) {
            setState(() => _vaultEnabled = value);
          }),
          _buildFeatureToggle('Video Tools', _videoToolsEnabled, (value) {
            setState(() => _videoToolsEnabled = value);
          }),
          _buildFeatureToggle('QR Scanner', _qrScannerEnabled, (value) {
            setState(() => _qrScannerEnabled = value);
          }),
          _buildFeatureToggle('Document Scanner', _documentScannerEnabled, (value) {
            setState(() => _documentScannerEnabled = value);
          }),
          _buildFeatureToggle('PDF Tools', _pdfToolsEnabled, (value) {
            setState(() => _pdfToolsEnabled = value);
          }),
          _buildFeatureToggle('Image Tools', _imageToolsEnabled, (value) {
            setState(() => _imageToolsEnabled = value);
          }),
          _buildFeatureToggle('Cleanup Engine', _cleanupEngineEnabled, (value) {
            setState(() => _cleanupEngineEnabled = value);
          }),

          const Divider(height: 32),

          // UI Customization
          _buildSectionHeader('UI Customization', context),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Primary Accent Color',
                  style: Theme.of(context).textTheme.titleSmall,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: Color(int.parse(_primaryColor.replaceFirst('#', '0xff'))),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        controller: TextEditingController(text: _primaryColor),
                        onChanged: (value) {
                          setState(() => _primaryColor = value);
                        },
                        decoration: InputDecoration(
                          hintText: '#10B981',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const Divider(height: 32),

          // System Configuration
          _buildSectionHeader('System Configuration', context),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Encryption Type',
                  style: Theme.of(context).textTheme.titleSmall,
                ),
                const SizedBox(height: 8),
                DropdownButton<String>(
                  value: _encryptionType,
                  isExpanded: true,
                  items: const [
                    DropdownMenuItem(value: 'AES-256', child: Text('AES-256')),
                    DropdownMenuItem(value: 'ChaCha20', child: Text('ChaCha20')),
                  ],
                  onChanged: (value) {
                    setState(() => _encryptionType = value ?? 'AES-256');
                  },
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Recently Deleted Retention Days',
                  style: Theme.of(context).textTheme.titleSmall,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: Slider(
                        value: _retentionDays.toDouble(),
                        min: 7,
                        max: 90,
                        divisions: 83,
                        label: '$_retentionDays days',
                        onChanged: (value) {
                          setState(() => _retentionDays = value.toInt());
                        },
                      ),
                    ),
                    Text(
                      '$_retentionDays',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                  ],
                ),
              ],
            ),
          ),

          const Divider(height: 32),

          // Master Reset
          _buildSectionHeader('Danger Zone', context),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                backgroundColor: Colors.red,
              ),
              onPressed: () => _showMasterResetDialog(),
              child: const Text('Master Reset - Wipe All Data'),
            ),
          ),

          const SizedBox(height: 24),
        ],
      ),
    );
  }

  /// Build section header
  Widget _buildSectionHeader(String title, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          title,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                color: Colors.red,
                fontWeight: FontWeight.bold,
              ),
        ),
      ),
    );
  }

  /// Build feature toggle
  Widget _buildFeatureToggle(
    String name,
    bool value,
    Function(bool) onChanged,
  ) {
    return ListTile(
      title: Text(name),
      trailing: Switch(
        value: value,
        onChanged: onChanged,
      ),
      onTap: () => onChanged(!value),
    );
  }

  /// Show master reset dialog
  void _showMasterResetDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Master Reset'),
        content: const Text(
          'This will permanently delete all app data, databases, and cache. This action cannot be undone!',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Master reset completed. App will restart...'),
                  duration: Duration(seconds: 3),
                ),
              );
              // In real app, this would trigger app restart
              Future.delayed(const Duration(seconds: 3), () {
                Navigator.pop(context);
              });
            },
            child: const Text('Confirm Reset'),
          ),
        ],
      ),
    );
  }
}
