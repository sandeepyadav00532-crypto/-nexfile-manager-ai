import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _selectedTheme = 'dark'; // light, dark, amoled
  String _selectedLanguage = 'en'; // en, hi, mr, gu, ta, te, kn, bn
  bool _showHiddenFiles = false;
  bool _showSystemFiles = false;
  bool _smartSearch = true;

  final Map<String, String> languages = {
    'en': 'English',
    'hi': 'हिन्दी (Hindi)',
    'mr': 'मराठी (Marathi)',
    'gu': 'ગુજરાતી (Gujarati)',
    'ta': 'தமிழ் (Tamil)',
    'te': 'తెలుగు (Telugu)',
    'kn': 'ಕನ್ನಡ (Kannada)',
    'bn': 'বাংলা (Bengali)',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Display Settings
            _buildSectionHeader('Display', context),
            _buildSettingTile(
              'Theme',
              Icons.palette_outlined,
              () => _showThemeDialog(),
            ),
            _buildSettingTile(
              'Language',
              Icons.language_outlined,
              () => _showLanguageDialog(),
            ),

            const Divider(height: 32),

            // File Management
            _buildSectionHeader('File Management', context),
            _buildSwitchTile(
              'Show Hidden Files',
              'Display files starting with .',
              Icons.visibility_off_outlined,
              _showHiddenFiles,
              (value) => setState(() => _showHiddenFiles = value),
            ),
            _buildSwitchTile(
              'Show System Files',
              'Display system and app files',
              Icons.settings_outlined,
              _showSystemFiles,
              (value) => setState(() => _showSystemFiles = value),
            ),
            _buildSwitchTile(
              'Smart Search',
              'Enhanced search with AI',
              Icons.search_outlined,
              _smartSearch,
              (value) => setState(() => _smartSearch = value),
            ),

            const Divider(height: 32),

            // Storage & Cleanup
            _buildSectionHeader('Storage & Cleanup', context),
            _buildSettingTile(
              'Clear Cache',
              Icons.delete_outline,
              () => _showClearCacheDialog(),
            ),
            _buildSettingTile(
              'Clear History',
              Icons.history_outlined,
              () => _showClearHistoryDialog(),
            ),
            _buildSettingTile(
              'Auto Cleanup',
              Icons.cleaning_services_outlined,
              () => _showAutoCleanupDialog(),
            ),

            const Divider(height: 32),

            // About & Help
            _buildSectionHeader('About & Help', context),
            _buildSettingTile(
              'About',
              Icons.info_outline,
              () => _showAboutDialog(),
            ),
            _buildSettingTile(
              'Privacy Policy',
              Icons.privacy_tip_outlined,
              () => _showPrivacyDialog(),
            ),
            _buildSettingTile(
              'Terms of Service',
              Icons.description_outlined,
              () => _showTermsDialog(),
            ),
            _buildSettingTile(
              'Rate App',
              Icons.star_outline,
              () => _showRateAppDialog(),
            ),

            const Divider(height: 32),

            // Premium
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                  backgroundColor: Theme.of(context).primaryColor,
                ),
                onPressed: () => _showPremiumDialog(),
                child: const Text(
                  'Upgrade to Premium',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  /// Build section header
  Widget _buildSectionHeader(String title, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          title,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                color: Theme.of(context).primaryColor,
                fontWeight: FontWeight.bold,
              ),
        ),
      ),
    );
  }

  /// Build setting tile
  Widget _buildSettingTile(String title, IconData icon, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: onTap,
    );
  }

  /// Build switch tile
  Widget _buildSwitchTile(
    String title,
    String subtitle,
    IconData icon,
    bool value,
    Function(bool) onChanged,
  ) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: Switch(value: value, onChanged: onChanged),
      onTap: () => onChanged(!value),
    );
  }

  /// Show theme dialog
  void _showThemeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Theme'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile(
              title: const Text('Light'),
              value: 'light',
              groupValue: _selectedTheme,
              onChanged: (value) {
                setState(() => _selectedTheme = value ?? 'light');
                Navigator.pop(context);
              },
            ),
            RadioListTile(
              title: const Text('Dark'),
              value: 'dark',
              groupValue: _selectedTheme,
              onChanged: (value) {
                setState(() => _selectedTheme = value ?? 'dark');
                Navigator.pop(context);
              },
            ),
            RadioListTile(
              title: const Text('AMOLED Black'),
              value: 'amoled',
              groupValue: _selectedTheme,
              onChanged: (value) {
                setState(() => _selectedTheme = value ?? 'amoled');
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  /// Show language dialog
  void _showLanguageDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Language'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: languages.length,
            itemBuilder: (context, index) {
              final key = languages.keys.toList()[index];
              final value = languages[key]!;
              return RadioListTile(
                title: Text(value),
                value: key,
                groupValue: _selectedLanguage,
                onChanged: (v) {
                  setState(() => _selectedLanguage = v ?? 'en');
                  Navigator.pop(context);
                },
              );
            },
          ),
        ),
      ),
    );
  }

  /// Show clear cache dialog
  void _showClearCacheDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Cache'),
        content: const Text('This will clear all cached files. Continue?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Cache cleared successfully')),
              );
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  /// Show clear history dialog
  void _showClearHistoryDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear History'),
        content: const Text('This will clear all search and access history. Continue?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('History cleared successfully')),
              );
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  /// Show auto cleanup dialog
  void _showAutoCleanupDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Auto Cleanup'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile(
              title: const Text('Disabled'),
              value: 'disabled',
              groupValue: 'disabled',
              onChanged: (value) {},
            ),
            RadioListTile(
              title: const Text('Weekly'),
              value: 'weekly',
              groupValue: 'disabled',
              onChanged: (value) {},
            ),
            RadioListTile(
              title: const Text('Monthly'),
              value: 'monthly',
              groupValue: 'disabled',
              onChanged: (value) {},
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  /// Show about dialog
  void _showAboutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('About NexFile Manager'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Version: 1.0.0'),
            SizedBox(height: 12),
            Text('A powerful file manager with AI-powered search, secure vault, and advanced tools.'),
            SizedBox(height: 12),
            Text('© 2024 NexFile. All rights reserved.'),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  /// Show privacy dialog
  void _showPrivacyDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Privacy Policy'),
        content: const SingleChildScrollView(
          child: Text(
            'Your privacy is important to us. We do not collect or share your personal data without consent.',
          ),
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  /// Show terms dialog
  void _showTermsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Terms of Service'),
        content: const SingleChildScrollView(
          child: Text(
            'By using NexFile Manager, you agree to our terms and conditions.',
          ),
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  /// Show rate app dialog
  void _showRateAppDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rate NexFile Manager'),
        content: const Text('Do you enjoy using NexFile Manager? Please rate us on the Play Store!'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Later'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Opening Play Store...')),
              );
            },
            child: const Text('Rate'),
          ),
        ],
      ),
    );
  }

  /// Show premium dialog
  void _showPremiumDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Premium Features'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('✓ Unlimited file storage'),
            SizedBox(height: 8),
            Text('✓ Advanced AI search'),
            SizedBox(height: 8),
            Text('✓ Batch operations'),
            SizedBox(height: 8),
            Text('✓ Cloud sync'),
            SizedBox(height: 8),
            Text('✓ Ad-free experience'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Opening premium options...')),
              );
            },
            child: const Text('Upgrade'),
          ),
        ],
      ),
    );
  }
}
