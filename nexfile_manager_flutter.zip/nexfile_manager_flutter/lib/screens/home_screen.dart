import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/storage_controller.dart';
import '../models/file_model.dart';
import '../providers/file_provider.dart';
import '../widgets/category_card.dart';
import '../widgets/recent_file_card.dart';
import '../widgets/storage_status_bar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<FileModel> _searchResults = [];
  bool _isSearching = false;

  final List<Map<String, dynamic>> categories = [
    {'name': 'Downloads', 'icon': '⬇️', 'count': 342, 'size': '2.3 GB'},
    {'name': 'Images', 'icon': '🖼️', 'count': 1205, 'size': '4.1 GB'},
    {'name': 'Videos', 'icon': '🎬', 'count': 87, 'size': '18.5 GB'},
    {'name': 'Audio', 'icon': '🎵', 'count': 456, 'size': '1.2 GB'},
    {'name': 'Documents', 'icon': '📝', 'count': 234, 'size': '890 MB'},
    {'name': 'PDFs', 'icon': '📄', 'count': 122, 'size': '456 MB'},
    {'name': 'APK Files', 'icon': '📱', 'count': 45, 'size': '3.2 GB'},
    {'name': 'ZIP/RAR', 'icon': '📦', 'count': 67, 'size': '5.6 GB'},
    {'name': 'E-books', 'icon': '📚', 'count': 89, 'size': '234 MB'},
    {'name': 'WhatsApp', 'icon': '💬', 'count': 523, 'size': '2.8 GB'},
    {'name': 'Telegram', 'icon': '✈️', 'count': 156, 'size': '1.5 GB'},
  ];

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  /// Handle search with debounce
  void _onSearchChanged() {
    if (_searchController.text.isEmpty) {
      setState(() {
        _isSearching = false;
        _searchResults = [];
      });
      return;
    }

    setState(() {
      _isSearching = true;
    });

    // Simulate search (in real app, this would call FileProvider)
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) {
        setState(() {
          _searchResults = [
            FileModel(
              id: '1',
              name: 'Document.pdf',
              path: '/storage/emulated/0/Documents/Document.pdf',
              size: 2048576,
              mimeType: 'application/pdf',
              category: 'Documents',
              lastModified: DateTime.now(),
            ),
            FileModel(
              id: '2',
              name: 'Photo.jpg',
              path: '/storage/emulated/0/Pictures/Photo.jpg',
              size: 3145728,
              mimeType: 'image/jpeg',
              category: 'Images',
              lastModified: DateTime.now(),
            ),
          ];
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('NexFile Manager'),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Search Bar
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      decoration: InputDecoration(
                        hintText: 'Search files...',
                        prefixIcon: const Icon(Icons.search),
                        suffixIcon: _searchController.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () {
                                  _searchController.clear();
                                },
                              )
                            : null,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.mic, color: Colors.white),
                      onPressed: () {
                        // Voice search
                      },
                    ),
                  ),
                ],
              ),
            ),

            // Show search results or home content
            if (_isSearching && _searchResults.isNotEmpty)
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Search Results (${_searchResults.length})',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 12),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _searchResults.length,
                      itemBuilder: (context, index) {
                        final file = _searchResults[index];
                        return RecentFileCard(file: file);
                      },
                    ),
                  ],
                ),
              )
            else if (!_isSearching) ...[
              // Storage Status Bar
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Consumer<StorageController>(
                  builder: (context, storageController, _) {
                    return StorageStatusBar(
                      usedStorage: storageController.storageStats.usedStorage,
                      totalStorage: storageController.storageStats.totalStorage,
                      usagePercentage: storageController.storageStats.usagePercentage,
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),

              // Recent Files Section
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Recent Files',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        TextButton(
                          onPressed: () {},
                          child: const Text('View All'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 120,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: 5,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.only(right: 12),
                            child: RecentFileCard(
                              file: FileModel(
                                id: index.toString(),
                                name: 'File $index',
                                path: '/path/to/file',
                                size: 1024 * 1024 * (index + 1),
                                mimeType: 'application/octet-stream',
                                category: 'Recent',
                                lastModified: DateTime.now(),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Categories Section
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Categories',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 12),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 1.2,
                      ),
                      itemCount: categories.length,
                      itemBuilder: (context, index) {
                        final category = categories[index];
                        return CategoryCard(
                          name: category['name'],
                          icon: category['icon'],
                          count: category['count'],
                          size: category['size'],
                          onTap: () {
                            // Navigate to category files
                          },
                        );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Collections Section
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Collections',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 12),
                    GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 1.2,
                      children: [
                        _buildCollectionCard('⭐ Starred', '45 files', context),
                        _buildCollectionCard('❤️ Favorites', '23 files', context),
                        _buildCollectionCard('🔒 Safe Folder', '12 files', context),
                        _buildCollectionCard('🗑️ Recently Deleted', '8 files', context),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
            ],
          ],
        ),
      ),
    );
  }

  /// Build collection card
  Widget _buildCollectionCard(String title, String subtitle, BuildContext context) {
    return Card(
      child: InkWell(
        onTap: () {},
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.titleSmall,
              ),
              const SizedBox(height: 8),
              Text(
                subtitle,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey,
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
