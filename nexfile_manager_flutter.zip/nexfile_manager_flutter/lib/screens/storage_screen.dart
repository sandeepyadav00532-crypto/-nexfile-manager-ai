import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/storage_controller.dart';

class StorageScreen extends StatefulWidget {
  const StorageScreen({Key? key}) : super(key: key);

  @override
  State<StorageScreen> createState() => _StorageScreenState();
}

class _StorageScreenState extends State<StorageScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<StorageController>().initializeStorage();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Storage Analysis'),
        elevation: 0,
      ),
      body: Consumer<StorageController>(
        builder: (context, storageController, _) {
          if (storageController.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (storageController.error != null) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 48, color: Colors.red),
                  const SizedBox(height: 16),
                  Text(storageController.error ?? 'Error loading storage'),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () => storageController.refreshStorageStats(),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            );
          }

          final stats = storageController.storageStats;
          final categoryStorage = storageController.categoryStorage;

          return SingleChildScrollView(
            child: Column(
              children: [
                // Storage Gauge
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 200,
                        width: 200,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            CircularProgressIndicator(
                              value: stats.usagePercentage / 100,
                              minHeight: 12,
                              backgroundColor: Colors.grey[300],
                              valueColor: AlwaysStoppedAnimation<Color>(
                                _getStorageColor(stats.usagePercentage),
                              ),
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  '${stats.usagePercentage.toStringAsFixed(1)}%',
                                  style: Theme.of(context).textTheme.headlineMedium,
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'Storage Used',
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildStorageInfo(
                            'Used',
                            StorageController.formatBytes(stats.usedStorage),
                            context,
                          ),
                          _buildStorageInfo(
                            'Free',
                            StorageController.formatBytes(stats.freeStorage),
                            context,
                          ),
                          _buildStorageInfo(
                            'Total',
                            StorageController.formatBytes(stats.totalStorage),
                            context,
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        storageController.getStorageStatusMessage(),
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: _getStorageColor(stats.usagePercentage),
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ],
                  ),
                ),

                // Category Breakdown
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Storage Breakdown',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 16),
                      ...categoryStorage.entries.map((entry) {
                        final percentage = storageController.getCategoryPercentage(entry.key);
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(entry.key),
                                  Text(
                                    StorageController.formatBytes(entry.value),
                                    style: Theme.of(context).textTheme.bodySmall,
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: LinearProgressIndicator(
                                  value: percentage / 100,
                                  minHeight: 8,
                                  backgroundColor: Colors.grey[300],
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    _getCategoryColor(entry.key),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ],
                  ),
                ),

                // Cleanup Options
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Cleanup Options',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 16),
                      _buildCleanupOption(
                        context,
                        'Cache Files',
                        'Clear recoverable app cache',
                        Icons.delete_outline,
                        onTap: () => _showCleanupDialog(context, 'Cache Files'),
                      ),
                      const SizedBox(height: 12),
                      _buildCleanupOption(
                        context,
                        'Temporary Files',
                        'Clear system temporary files',
                        Icons.folder_open_outlined,
                        onTap: () => _showCleanupDialog(context, 'Temporary Files'),
                      ),
                      const SizedBox(height: 12),
                      _buildCleanupOption(
                        context,
                        'Duplicate Files',
                        'Find and remove duplicate files',
                        Icons.copy_outlined,
                        onTap: () => _showCleanupDialog(context, 'Duplicate Files'),
                      ),
                      const SizedBox(height: 12),
                      _buildCleanupOption(
                        context,
                        'Large Files',
                        'Find files larger than 50MB',
                        Icons.storage_outlined,
                        onTap: () => _showCleanupDialog(context, 'Large Files'),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),
              ],
            ),
          );
        },
      ),
    );
  }

  /// Build storage info widget
  Widget _buildStorageInfo(String label, String value, BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: Theme.of(context).textTheme.titleSmall,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey,
              ),
        ),
      ],
    );
  }

  /// Build cleanup option card
  Widget _buildCleanupOption(
    BuildContext context,
    String title,
    String subtitle,
    IconData icon, {
    required VoidCallback onTap,
  }) {
    return Card(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(icon, color: Theme.of(context).primaryColor),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Colors.grey,
                          ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, size: 16),
            ],
          ),
        ),
      ),
    );
  }

  /// Show cleanup confirmation dialog
  void _showCleanupDialog(BuildContext context, String cleanupType) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Clean $cleanupType?'),
        content: Text('This action will remove $cleanupType from your device.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _performCleanup(context, cleanupType);
            },
            child: const Text('Clean'),
          ),
        ],
      ),
    );
  }

  /// Perform cleanup
  void _performCleanup(BuildContext context, String cleanupType) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Cleaning $cleanupType...'),
        duration: const Duration(seconds: 2),
      ),
    );

    // Simulate cleanup
    Future.delayed(const Duration(seconds: 2), () {
      context.read<StorageController>().refreshStorageStats();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$cleanupType cleaned successfully!'),
          duration: const Duration(seconds: 2),
        ),
      );
    });
  }

  /// Get storage color based on percentage
  Color _getStorageColor(double percentage) {
    if (percentage < 50) return Colors.green;
    if (percentage < 75) return Colors.orange;
    if (percentage < 90) return Colors.deepOrange;
    return Colors.red;
  }

  /// Get category color
  Color _getCategoryColor(String category) {
    const colors = {
      'Images': Color(0xFF10B981),
      'Videos': Color(0xFF06B6D4),
      'Audio': Color(0xFFF59E0B),
      'Documents': Color(0xFF8B5CF6),
      'Apps': Color(0xFFEF4444),
      'Other': Color(0xFF6B7280),
    };
    return colors[category] ?? Colors.grey;
  }
}
