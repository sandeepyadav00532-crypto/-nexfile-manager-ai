import 'package:flutter/material.dart';

class VaultScreen extends StatefulWidget {
  const VaultScreen({Key? key}) : super(key: key);

  @override
  State<VaultScreen> createState() => _VaultScreenState();
}

class _VaultScreenState extends State<VaultScreen> {
  bool _isVaultUnlocked = false;
  String _unlockMethod = 'biometric'; // biometric, pin, pattern

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Safe Folder'),
        elevation: 0,
      ),
      body: _isVaultUnlocked ? _buildVaultContent() : _buildLockScreen(),
    );
  }

  /// Build lock screen
  Widget _buildLockScreen() {
    return Center(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Lock icon
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(50),
                ),
                child: Icon(
                  Icons.lock_outline,
                  size: 50,
                  color: Theme.of(context).primaryColor,
                ),
              ),
              const SizedBox(height: 24),

              // Title
              Text(
                'Safe Folder Locked',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              Text(
                'Your files are encrypted and secured',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.grey,
                    ),
              ),
              const SizedBox(height: 48),

              // Unlock options
              _buildUnlockOption(
                'Biometric',
                Icons.fingerprint,
                'Face ID or Fingerprint',
                () => _unlockWithBiometric(),
              ),
              const SizedBox(height: 16),
              _buildUnlockOption(
                'PIN',
                Icons.pin,
                '4-6 digit PIN',
                () => _unlockWithPIN(),
              ),
              const SizedBox(height: 16),
              _buildUnlockOption(
                'Pattern',
                Icons.grid_3x3,
                'Draw a pattern',
                () => _unlockWithPattern(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Build unlock option button
  Widget _buildUnlockOption(
    String title,
    IconData icon,
    String subtitle,
    VoidCallback onTap,
  ) {
    return Card(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: Theme.of(context).primaryColor),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Colors.grey,
                          ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, size: 16),
            ],
          ),
        ),
      ),
    );
  }

  /// Unlock with biometric
  void _unlockWithBiometric() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Biometric Authentication'),
        content: const Text('Place your finger on the sensor or look at the camera'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() => _isVaultUnlocked = true);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Vault unlocked')),
              );
            },
            child: const Text('Authenticate'),
          ),
        ],
      ),
    );
  }

  /// Unlock with PIN
  void _unlockWithPIN() {
    final pinController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Enter PIN'),
        content: TextField(
          controller: pinController,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 6,
          decoration: const InputDecoration(
            hintText: 'Enter 4-6 digit PIN',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (pinController.text.length >= 4) {
                Navigator.pop(context);
                setState(() => _isVaultUnlocked = true);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Vault unlocked')),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('PIN must be at least 4 digits')),
                );
              }
            },
            child: const Text('Unlock'),
          ),
        ],
      ),
    );
  }

  /// Unlock with pattern
  void _unlockWithPattern() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Draw Pattern'),
        content: const SizedBox(
          height: 300,
          child: Center(
            child: Text('Pattern drawing interface would go here'),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() => _isVaultUnlocked = true);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Vault unlocked')),
              );
            },
            child: const Text('Verify'),
          ),
        ],
      ),
    );
  }

  /// Build vault content (unlocked)
  Widget _buildVaultContent() {
    return SingleChildScrollView(
      child: Column(
        children: [
          // Vault header
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withOpacity(0.1),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Safe Folder',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'AES-256 Encrypted',
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: Colors.grey,
                              ),
                        ),
                      ],
                    ),
                    ElevatedButton(
                      onPressed: () {
                        setState(() => _isVaultUnlocked = false);
                      },
                      child: const Text('Lock'),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Vault stats
          Padding(
            padding: const EdgeInsets.all(24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStatCard('12', 'Files'),
                _buildStatCard('2.5 GB', 'Storage'),
                _buildStatCard('3', 'Types'),
              ],
            ),
          ),

          // Security settings
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Security Settings',
                  style: Theme.of(context).textTheme.titleSmall,
                ),
                const SizedBox(height: 12),
                _buildSecurityOption('Biometric', Icons.fingerprint, true),
                _buildSecurityOption('PIN', Icons.pin, true),
                _buildSecurityOption('Pattern', Icons.grid_3x3, false),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Vault files
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Vault Files',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    ElevatedButton.icon(
                      onPressed: () {},
                      icon: const Icon(Icons.add),
                      label: const Text('Add'),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _buildVaultFileItem('Document.pdf', '2.4 MB', Icons.picture_as_pdf),
                _buildVaultFileItem('Photo.jpg', '3.1 MB', Icons.image),
                _buildVaultFileItem('Video.mp4', '156 MB', Icons.videocam),
              ],
            ),
          ),

          const SizedBox(height: 24),
        ],
      ),
    );
  }

  /// Build stat card
  Widget _buildStatCard(String value, String label) {
    return Column(
      children: [
        Text(
          value,
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey,
              ),
        ),
      ],
    );
  }

  /// Build security option
  Widget _buildSecurityOption(String title, IconData icon, bool enabled) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Icon(icon, color: Theme.of(context).primaryColor),
          const SizedBox(width: 12),
          Expanded(
            child: Text(title),
          ),
          Switch(
            value: enabled,
            onChanged: (value) {},
          ),
        ],
      ),
    );
  }

  /// Build vault file item
  Widget _buildVaultFileItem(String name, String size, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(icon, color: Theme.of(context).primaryColor),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name),
                  const SizedBox(height: 4),
                  Text(
                    size,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.grey,
                        ),
                  ),
                ],
              ),
            ),
            PopupMenuButton(
              itemBuilder: (context) => [
                const PopupMenuItem(child: Text('Download')),
                const PopupMenuItem(child: Text('Delete')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
