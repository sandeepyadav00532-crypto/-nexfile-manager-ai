import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart';

/// DatabaseService - Manages SQLite database for file tracking and settings
class DatabaseService {
  static const String _databaseName = 'nexfile_manager.db';
  static const int _databaseVersion = 1;

  Database? _database;
  final SharedPreferences _prefs;

  DatabaseService(this._prefs);

  /// Get database instance
  Future<Database> get database async {
    _database ??= await initializeDatabase();
    return _database!;
  }

  /// Initialize database and create tables
  Future<Database> initializeDatabase() async {
    try {
      final databasePath = await getDatabasesPath();
      final path = join(databasePath, _databaseName);

      return await openDatabase(
        path,
        version: _databaseVersion,
        onCreate: _createTables,
        onUpgrade: _upgradeTables,
      );
    } catch (e) {
      debugPrint('Error initializing database: $e');
      rethrow;
    }
  }

  /// Create all tables
  Future<void> _createTables(Database db, int version) async {
    try {
      // Files table
      await db.execute('''
        CREATE TABLE IF NOT EXISTS files (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          path TEXT NOT NULL UNIQUE,
          size INTEGER NOT NULL,
          mimeType TEXT,
          category TEXT,
          lastModified TEXT NOT NULL,
          isStarred INTEGER DEFAULT 0,
          isFavorite INTEGER DEFAULT 0,
          isInVault INTEGER DEFAULT 0,
          createdAt TEXT DEFAULT CURRENT_TIMESTAMP
        )
      ''');

      // Vault files table
      await db.execute('''
        CREATE TABLE IF NOT EXISTS vault_files (
          id TEXT PRIMARY KEY,
          originalName TEXT NOT NULL,
          encryptedPath TEXT NOT NULL,
          originalPath TEXT,
          size INTEGER NOT NULL,
          addedDate TEXT NOT NULL,
          mimeType TEXT,
          createdAt TEXT DEFAULT CURRENT_TIMESTAMP
        )
      ''');

      // Recycle bin table (Recently deleted files)
      await db.execute('''
        CREATE TABLE IF NOT EXISTS recycle_bin (
          id TEXT PRIMARY KEY,
          originalName TEXT NOT NULL,
          originalPath TEXT NOT NULL,
          deletedPath TEXT NOT NULL,
          size INTEGER NOT NULL,
          mimeType TEXT,
          category TEXT,
          deletedAt TEXT NOT NULL,
          expiresAt TEXT NOT NULL,
          isRestored INTEGER DEFAULT 0
        )
      ''');

      // Vault settings table
      await db.execute('''
        CREATE TABLE IF NOT EXISTS vault_settings (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        )
      ''');

      // Admin settings table
      await db.execute('''
        CREATE TABLE IF NOT EXISTS admin_settings (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        )
      ''');

      // File collections table (Starred, Favorites, Shared)
      await db.execute('''
        CREATE TABLE IF NOT EXISTS collections (
          id TEXT PRIMARY KEY,
          fileId TEXT NOT NULL,
          collectionType TEXT NOT NULL,
          addedAt TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (fileId) REFERENCES files(id)
        )
      ''');

      // Search history table
      await db.execute('''
        CREATE TABLE IF NOT EXISTS search_history (
          id TEXT PRIMARY KEY,
          query TEXT NOT NULL,
          searchedAt TEXT DEFAULT CURRENT_TIMESTAMP
        )
      ''');

      debugPrint('Database tables created successfully');
    } catch (e) {
      debugPrint('Error creating tables: $e');
      rethrow;
    }
  }

  /// Handle database upgrades
  Future<void> _upgradeTables(Database db, int oldVersion, int newVersion) async {
    debugPrint('Upgrading database from version $oldVersion to $newVersion');
    // Add migration logic here as needed
  }

  /// Insert file
  Future<void> insertFile(Map<String, dynamic> fileData) async {
    try {
      final db = await database;
      await db.insert(
        'files',
        fileData,
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } catch (e) {
      debugPrint('Error inserting file: $e');
    }
  }

  /// Get all files
  Future<List<Map<String, dynamic>>> getAllFiles() async {
    try {
      final db = await database;
      return await db.query('files', orderBy: 'lastModified DESC');
    } catch (e) {
      debugPrint('Error getting all files: $e');
      return [];
    }
  }

  /// Get files by category
  Future<List<Map<String, dynamic>>> getFilesByCategory(String category) async {
    try {
      final db = await database;
      return await db.query(
        'files',
        where: 'category = ?',
        whereArgs: [category],
        orderBy: 'lastModified DESC',
      );
    } catch (e) {
      debugPrint('Error getting files by category: $e');
      return [];
    }
  }

  /// Get starred files
  Future<List<Map<String, dynamic>>> getStarredFiles() async {
    try {
      final db = await database;
      return await db.query(
        'files',
        where: 'isStarred = ?',
        whereArgs: [1],
        orderBy: 'lastModified DESC',
      );
    } catch (e) {
      debugPrint('Error getting starred files: $e');
      return [];
    }
  }

  /// Get favorite files
  Future<List<Map<String, dynamic>>> getFavoriteFiles() async {
    try {
      final db = await database;
      return await db.query(
        'files',
        where: 'isFavorite = ?',
        whereArgs: [1],
        orderBy: 'lastModified DESC',
      );
    } catch (e) {
      debugPrint('Error getting favorite files: $e');
      return [];
    }
  }

  /// Get recent files (last 30 days)
  Future<List<Map<String, dynamic>>> getRecentFiles({int limit = 50}) async {
    try {
      final db = await database;
      final thirtyDaysAgo = DateTime.now().subtract(const Duration(days: 30));
      return await db.query(
        'files',
        where: 'lastModified > ?',
        whereArgs: [thirtyDaysAgo.toIso8601String()],
        orderBy: 'lastModified DESC',
        limit: limit,
      );
    } catch (e) {
      debugPrint('Error getting recent files: $e');
      return [];
    }
  }

  /// Search files by name
  Future<List<Map<String, dynamic>>> searchFiles(String query) async {
    try {
      final db = await database;
      return await db.query(
        'files',
        where: 'name LIKE ?',
        whereArgs: ['%$query%'],
        limit: 100,
      );
    } catch (e) {
      debugPrint('Error searching files: $e');
      return [];
    }
  }

  /// Update file (star, favorite, vault status)
  Future<void> updateFile(String fileId, Map<String, dynamic> updates) async {
    try {
      final db = await database;
      await db.update(
        'files',
        updates,
        where: 'id = ?',
        whereArgs: [fileId],
      );
    } catch (e) {
      debugPrint('Error updating file: $e');
    }
  }

  /// Delete file from database
  Future<void> deleteFile(String fileId) async {
    try {
      final db = await database;
      await db.delete(
        'files',
        where: 'id = ?',
        whereArgs: [fileId],
      );
    } catch (e) {
      debugPrint('Error deleting file: $e');
    }
  }

  /// Get category statistics
  Future<Map<String, dynamic>> getCategoryStats(String category) async {
    try {
      final db = await database;
      final result = await db.rawQuery(
        'SELECT COUNT(*) as count, SUM(size) as totalSize FROM files WHERE category = ?',
        [category],
      );

      if (result.isNotEmpty) {
        return {
          'count': result.first['count'] ?? 0,
          'totalSize': result.first['totalSize'] ?? 0,
        };
      }
      return {'count': 0, 'totalSize': 0};
    } catch (e) {
      debugPrint('Error getting category stats: $e');
      return {'count': 0, 'totalSize': 0};
    }
  }

  /// Add file to recycle bin
  Future<void> addToRecycleBin(Map<String, dynamic> deletedFileData) async {
    try {
      final db = await database;
      await db.insert(
        'recycle_bin',
        deletedFileData,
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } catch (e) {
      debugPrint('Error adding to recycle bin: $e');
    }
  }

  /// Get recycle bin files
  Future<List<Map<String, dynamic>>> getRecycleBinFiles() async {
    try {
      final db = await database;
      return await db.query(
        'recycle_bin',
        where: 'isRestored = ?',
        whereArgs: [0],
        orderBy: 'deletedAt DESC',
      );
    } catch (e) {
      debugPrint('Error getting recycle bin files: $e');
      return [];
    }
  }

  /// Restore file from recycle bin
  Future<void> restoreFromRecycleBin(String recycleBinId) async {
    try {
      final db = await database;
      await db.update(
        'recycle_bin',
        {'isRestored': 1},
        where: 'id = ?',
        whereArgs: [recycleBinId],
      );
    } catch (e) {
      debugPrint('Error restoring from recycle bin: $e');
    }
  }

  /// Permanently delete from recycle bin
  Future<void> permanentlyDeleteFromRecycleBin(String recycleBinId) async {
    try {
      final db = await database;
      await db.delete(
        'recycle_bin',
        where: 'id = ?',
        whereArgs: [recycleBinId],
      );
    } catch (e) {
      debugPrint('Error permanently deleting from recycle bin: $e');
    }
  }

  /// Auto-purge expired files from recycle bin
  Future<void> purgeExpiredRecycleBinFiles(int retentionDays) async {
    try {
      final db = await database;
      final expiryDate = DateTime.now().subtract(Duration(days: retentionDays));
      await db.delete(
        'recycle_bin',
        where: 'deletedAt < ?',
        whereArgs: [expiryDate.toIso8601String()],
      );
      debugPrint('Expired recycle bin files purged');
    } catch (e) {
      debugPrint('Error purging expired recycle bin files: $e');
    }
  }

  /// Add vault file
  Future<void> addVaultFile(Map<String, dynamic> vaultFileData) async {
    try {
      final db = await database;
      await db.insert(
        'vault_files',
        vaultFileData,
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } catch (e) {
      debugPrint('Error adding vault file: $e');
    }
  }

  /// Get vault files
  Future<List<Map<String, dynamic>>> getVaultFiles() async {
    try {
      final db = await database;
      return await db.query('vault_files', orderBy: 'addedDate DESC');
    } catch (e) {
      debugPrint('Error getting vault files: $e');
      return [];
    }
  }

  /// Delete vault file
  Future<void> deleteVaultFile(String vaultFileId) async {
    try {
      final db = await database;
      await db.delete(
        'vault_files',
        where: 'id = ?',
        whereArgs: [vaultFileId],
      );
    } catch (e) {
      debugPrint('Error deleting vault file: $e');
    }
  }

  /// Add search history
  Future<void> addSearchHistory(String query) async {
    try {
      final db = await database;
      await db.insert(
        'search_history',
        {
          'id': DateTime.now().millisecondsSinceEpoch.toString(),
          'query': query,
        },
      );
    } catch (e) {
      debugPrint('Error adding search history: $e');
    }
  }

  /// Get search history
  Future<List<String>> getSearchHistory({int limit = 10}) async {
    try {
      final db = await database;
      final results = await db.query(
        'search_history',
        orderBy: 'searchedAt DESC',
        limit: limit,
      );
      return results.map((r) => r['query'] as String).toList();
    } catch (e) {
      debugPrint('Error getting search history: $e');
      return [];
    }
  }

  /// Clear search history
  Future<void> clearSearchHistory() async {
    try {
      final db = await database;
      await db.delete('search_history');
    } catch (e) {
      debugPrint('Error clearing search history: $e');
    }
  }

  /// Save vault setting
  Future<void> saveVaultSetting(String key, String value) async {
    try {
      final db = await database;
      await db.insert(
        'vault_settings',
        {'key': key, 'value': value},
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } catch (e) {
      debugPrint('Error saving vault setting: $e');
    }
  }

  /// Get vault setting
  Future<String?> getVaultSetting(String key) async {
    try {
      final db = await database;
      final results = await db.query(
        'vault_settings',
        where: 'key = ?',
        whereArgs: [key],
      );
      if (results.isNotEmpty) {
        return results.first['value'] as String?;
      }
      return null;
    } catch (e) {
      debugPrint('Error getting vault setting: $e');
      return null;
    }
  }

  /// Clear all database (Master Reset)
  Future<void> clearAllData() async {
    try {
      final db = await database;
      await db.delete('files');
      await db.delete('vault_files');
      await db.delete('recycle_bin');
      await db.delete('vault_settings');
      await db.delete('admin_settings');
      await db.delete('collections');
      await db.delete('search_history');
      debugPrint('All database data cleared');
    } catch (e) {
      debugPrint('Error clearing database: $e');
    }
  }

  /// Close database
  Future<void> closeDatabase() async {
    if (_database != null) {
      await _database!.close();
      _database = null;
    }
  }
}
