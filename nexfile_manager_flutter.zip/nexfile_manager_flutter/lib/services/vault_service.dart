import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:local_auth/local_auth.dart';
import 'package:encrypt/encrypt.dart' as encrypt;
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import '../models/vault_file_model.dart';
import 'database_service.dart';

/// VaultService - Manages secure vault with biometric auth and encryption
class VaultService {
  final DatabaseService _databaseService;
  final LocalAuthentication _localAuth = LocalAuthentication();

  // Encryption keys
  late encrypt.Key _encryptionKey;
  late encrypt.IV _encryptionIV;
  bool _isVaultUnlocked = false;
  String? _vaultPIN;
  String? _vaultPattern;

  // Vault directory
  late Directory _vaultDirectory;

  VaultService(this._databaseService) {
    _initializeVault();
  }

  // Getters
  bool get isVaultUnlocked => _isVaultUnlocked;
  bool get hasBiometricSupport => _localAuth.canCheckBiometrics;

  /// Initialize vault directory and encryption
  Future<void> _initializeVault() async {
    try {
      final appDir = await getApplicationDocumentsDirectory();
      _vaultDirectory = Directory('${appDir.path}/.vault');

      if (!await _vaultDirectory.exists()) {
        await _vaultDirectory.create(recursive: true);
      }

      // Generate encryption key and IV
      _generateEncryptionKeys();

      // Initialize database
      await _databaseService.initializeDatabase();
    } catch (e) {
      debugPrint('Error initializing vault: $e');
    }
  }

  /// Generate encryption keys using SHA-256
  void _generateEncryptionKeys() {
    const masterPassword = 'NexFileVaultMaster2024';
    final key = sha256.convert(masterPassword.codeUnits).toString();
    _encryptionKey = encrypt.Key.fromUtf8(key.substring(0, 32));
    _encryptionIV = encrypt.IV.fromUtf8(key.substring(0, 16));
  }

  /// Setup vault with PIN
  Future<bool> setupVaultWithPIN(String pin) async {
    try {
      if (pin.length < 4 || pin.length > 6) {
        return false;
      }

      _vaultPIN = pin;
      final db = await _databaseService.database;

      // Store PIN hash
      final pinHash = sha256.convert(pin.codeUnits).toString();
      await db.insert(
        'vault_settings',
        {
          'key': 'pin_hash',
          'value': pinHash,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

      return true;
    } catch (e) {
      debugPrint('Error setting up vault PIN: $e');
      return false;
    }
  }

  /// Setup vault with pattern
  Future<bool> setupVaultWithPattern(String pattern) async {
    try {
      _vaultPattern = pattern;
      final db = await _databaseService.database;

      // Store pattern hash
      final patternHash = sha256.convert(pattern.codeUnits).toString();
      await db.insert(
        'vault_settings',
        {
          'key': 'pattern_hash',
          'value': patternHash,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

      return true;
    } catch (e) {
      debugPrint('Error setting up vault pattern: $e');
      return false;
    }
  }

  /// Unlock vault with biometric
  Future<bool> unlockWithBiometric() async {
    try {
      final isDeviceSupported = await _localAuth.canCheckBiometrics;
      final isDeviceSecure = await _localAuth.deviceSupportsBiometrics;

      if (!isDeviceSupported || !isDeviceSecure) {
        return false;
      }

      final isAuthenticated = await _localAuth.authenticate(
        localizedReason: 'Unlock your Safe Folder',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: true,
        ),
      );

      if (isAuthenticated) {
        _isVaultUnlocked = true;
        return true;
      }

      return false;
    } catch (e) {
      debugPrint('Error unlocking vault with biometric: $e');
      return false;
    }
  }

  /// Unlock vault with PIN
  Future<bool> unlockWithPIN(String enteredPIN) async {
    try {
      final db = await _databaseService.database;

      // Get stored PIN hash
      final results = await db.query(
        'vault_settings',
        where: 'key = ?',
        whereArgs: ['pin_hash'],
      );

      if (results.isEmpty) {
        return false;
      }

      final storedHash = results.first['value'] as String;
      final enteredHash = sha256.convert(enteredPIN.codeUnits).toString();

      if (storedHash == enteredHash) {
        _isVaultUnlocked = true;
        _vaultPIN = enteredPIN;
        return true;
      }

      return false;
    } catch (e) {
      debugPrint('Error unlocking vault with PIN: $e');
      return false;
    }
  }

  /// Unlock vault with pattern
  Future<bool> unlockWithPattern(String enteredPattern) async {
    try {
      final db = await _databaseService.database;

      // Get stored pattern hash
      final results = await db.query(
        'vault_settings',
        where: 'key = ?',
        whereArgs: ['pattern_hash'],
      );

      if (results.isEmpty) {
        return false;
      }

      final storedHash = results.first['value'] as String;
      final enteredHash = sha256.convert(enteredPattern.codeUnits).toString();

      if (storedHash == enteredHash) {
        _isVaultUnlocked = true;
        _vaultPattern = enteredPattern;
        return true;
      }

      return false;
    } catch (e) {
      debugPrint('Error unlocking vault with pattern: $e');
      return false;
    }
  }

  /// Lock vault
  void lockVault() {
    _isVaultUnlocked = false;
  }

  /// Add file to vault (encrypt and move)
  Future<bool> addFileToVault(String filePath) async {
    if (!_isVaultUnlocked) {
      return false;
    }

    try {
      final sourceFile = File(filePath);
      if (!await sourceFile.exists()) {
        return false;
      }

      // Read file
      final fileBytes = await sourceFile.readAsBytes();

      // Encrypt file
      final encrypter = encrypt.Encrypter(encrypt.AES(_encryptionKey));
      final encrypted = encrypter.encryptBytes(fileBytes, iv: _encryptionIV);

      // Save encrypted file to vault
      final fileName = filePath.split('/').last;
      final encryptedFilePath = '${_vaultDirectory.path}/$fileName.encrypted';
      await File(encryptedFilePath).writeAsBytes(encrypted.bytes);

      // Store metadata in database
      final db = await _databaseService.database;
      await db.insert(
        'vault_files',
        {
          'id': DateTime.now().millisecondsSinceEpoch.toString(),
          'originalName': fileName,
          'encryptedPath': encryptedFilePath,
          'originalPath': filePath,
          'size': fileBytes.length,
          'addedDate': DateTime.now().toIso8601String(),
          'mimeType': _getMimeType(fileName),
        },
      );

      // Delete original file
      await sourceFile.delete();

      return true;
    } catch (e) {
      debugPrint('Error adding file to vault: $e');
      return false;
    }
  }

  /// Remove file from vault (decrypt and restore)
  Future<bool> removeFileFromVault(String vaultFileId, String restorePath) async {
    if (!_isVaultUnlocked) {
      return false;
    }

    try {
      final db = await _databaseService.database;

      // Get vault file metadata
      final results = await db.query(
        'vault_files',
        where: 'id = ?',
        whereArgs: [vaultFileId],
      );

      if (results.isEmpty) {
        return false;
      }

      final vaultFile = results.first;
      final encryptedPath = vaultFile['encryptedPath'] as String;
      final originalName = vaultFile['originalName'] as String;

      // Read encrypted file
      final encryptedFile = File(encryptedPath);
      final encryptedBytes = await encryptedFile.readAsBytes();

      // Decrypt file
      final encrypter = encrypt.Encrypter(encrypt.AES(_encryptionKey));
      final decrypted = encrypter.decryptBytes(
        encrypt.Encrypted(encryptedBytes),
        iv: _encryptionIV,
      );

      // Save decrypted file to restore path
      final restoredFilePath = '$restorePath/$originalName';
      await File(restoredFilePath).writeAsBytes(decrypted);

      // Delete encrypted file
      await encryptedFile.delete();

      // Remove from database
      await db.delete(
        'vault_files',
        where: 'id = ?',
        whereArgs: [vaultFileId],
      );

      return true;
    } catch (e) {
      debugPrint('Error removing file from vault: $e');
      return false;
    }
  }

  /// Get all vault files
  Future<List<VaultFile>> getVaultFiles() async {
    if (!_isVaultUnlocked) {
      return [];
    }

    try {
      final db = await _databaseService.database;
      final results = await db.query('vault_files');

      return results.map((json) => VaultFile.fromJson(json)).toList();
    } catch (e) {
      debugPrint('Error getting vault files: $e');
      return [];
    }
  }

  /// Delete file from vault permanently
  Future<bool> deleteVaultFilePermanently(String vaultFileId) async {
    if (!_isVaultUnlocked) {
      return false;
    }

    try {
      final db = await _databaseService.database;

      // Get vault file metadata
      final results = await db.query(
        'vault_files',
        where: 'id = ?',
        whereArgs: [vaultFileId],
      );

      if (results.isEmpty) {
        return false;
      }

      final encryptedPath = results.first['encryptedPath'] as String;

      // Delete encrypted file
      await File(encryptedPath).delete();

      // Remove from database
      await db.delete(
        'vault_files',
        where: 'id = ?',
        whereArgs: [vaultFileId],
      );

      return true;
    } catch (e) {
      debugPrint('Error deleting vault file: $e');
      return false;
    }
  }

  /// Get vault statistics
  Future<Map<String, dynamic>> getVaultStats() async {
    if (!_isVaultUnlocked) {
      return {'fileCount': 0, 'totalSize': 0};
    }

    try {
      final db = await _databaseService.database;
      final results = await db.rawQuery(
        'SELECT COUNT(*) as count, SUM(size) as totalSize FROM vault_files',
      );

      if (results.isNotEmpty) {
        return {
          'fileCount': results.first['count'] ?? 0,
          'totalSize': results.first['totalSize'] ?? 0,
        };
      }

      return {'fileCount': 0, 'totalSize': 0};
    } catch (e) {
      debugPrint('Error getting vault stats: $e');
      return {'fileCount': 0, 'totalSize': 0};
    }
  }

  /// Helper: Get MIME type from filename
  String _getMimeType(String fileName) {
    final extension = fileName.split('.').last.toLowerCase();
    final mimeTypes = {
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'gif': 'image/gif',
      'mp4': 'video/mp4',
      'avi': 'video/x-msvideo',
      'mov': 'video/quicktime',
      'mp3': 'audio/mpeg',
      'wav': 'audio/wav',
      'pdf': 'application/pdf',
      'doc': 'application/msword',
      'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    };

    return mimeTypes[extension] ?? 'application/octet-stream';
  }

  /// Dispose resources
  void dispose() {
    _isVaultUnlocked = false;
  }
}
