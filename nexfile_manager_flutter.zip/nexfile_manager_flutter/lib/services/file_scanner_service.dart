import 'dart:io';
import 'dart:isolate';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:sqflite/sqflite.dart';
import '../models/file_model.dart';
import 'database_service.dart';

/// FileScannerService - Handles asynchronous file scanning using Isolates
/// Indexes files across all categories: Photos, Videos, Audio, Documents, APKs, etc.
class FileScannerService {
  final DatabaseService _databaseService;
  ReceivePort? _receivePort;
  Isolate? _isolate;
  bool _isScanning = false;

  FileScannerService(this._databaseService);

  /// Get scanning status
  bool get isScanning => _isScanning;

  /// Start background file scanning using Isolate
  Future<void> startBackgroundScan({
    required Function(List<FileModel>) onFilesFound,
    required Function(String) onProgress,
    required Function(String) onError,
  }) async {
    if (_isScanning) {
      onError('Scan already in progress');
      return;
    }

    _isScanning = true;
    _receivePort = ReceivePort();

    try {
      _isolate = await Isolate.spawn(
        _fileScannerIsolate,
        _receivePort!.sendPort,
      );

      // Listen for messages from isolate
      _receivePort!.listen((dynamic message) {
        if (message is String) {
          // Progress update
          onProgress(message);
        } else if (message is List<FileModel>) {
          // Files found
          onFilesFound(message);
        } else if (message is Map && message['error'] != null) {
          // Error occurred
          onError(message['error']);
        }
      });
    } catch (e) {
      _isScanning = false;
      onError('Failed to start scan: $e');
    }
  }

  /// Stop background scanning
  void stopScan() {
    _isolate?.kill(priority: Isolate.immediate);
    _receivePort?.close();
    _isScanning = false;
  }

  /// Isolate entry point for file scanning
  static Future<void> _fileScannerIsolate(SendPort sendPort) async {
    try {
      final files = <FileModel>[];

      // Scan Photos
      sendPort.send('Scanning Photos...');
      files.addAll(await _scanPhotos());

      // Scan Videos
      sendPort.send('Scanning Videos...');
      files.addAll(await _scanVideos());

      // Scan Audio
      sendPort.send('Scanning Audio...');
      files.addAll(await _scanAudio());

      // Scan Documents
      sendPort.send('Scanning Documents...');
      files.addAll(await _scanDocuments());

      // Scan PDFs
      sendPort.send('Scanning PDFs...');
      files.addAll(await _scanPDFs());

      // Scan APKs
      sendPort.send('Scanning APK Files...');
      files.addAll(await _scanAPKs());

      // Scan Archives
      sendPort.send('Scanning Archives...');
      files.addAll(await _scanArchives());

      // Scan E-books
      sendPort.send('Scanning E-books...');
      files.addAll(await _scanEBooks());

      // Scan WhatsApp Media
      sendPort.send('Scanning WhatsApp Media...');
      files.addAll(await _scanWhatsAppMedia());

      // Scan Telegram Media
      sendPort.send('Scanning Telegram Media...');
      files.addAll(await _scanTelegramMedia());

      // Send results
      sendPort.send(files);
    } catch (e) {
      sendPort.send({'error': 'Scan error: $e'});
    }
  }

  /// Scan Photos using PhotoManager
  static Future<List<FileModel>> _scanPhotos() async {
    final files = <FileModel>[];
    try {
      final albums = await PhotoManager.getAssetPathList(
        type: RequestType.image,
        hasAll: true,
      );

      for (final album in albums) {
        final assets = await album.getAssetListRange(
          start: 0,
          end: await album.assetCountAsync,
        );

        for (final asset in assets) {
          final file = await asset.file;
          if (file != null) {
            files.add(FileModel(
              id: asset.id,
              name: asset.title ?? 'Photo',
              path: file.path,
              size: await file.length(),
              mimeType: 'image/*',
              category: 'Images',
              lastModified: asset.modifiedDateTime ?? DateTime.now(),
              isStarred: false,
              isFavorite: false,
              isInVault: false,
            ));
          }
        }
      }
    } catch (e) {
      debugPrint('Error scanning photos: $e');
    }
    return files;
  }

  /// Scan Videos
  static Future<List<FileModel>> _scanVideos() async {
    final files = <FileModel>[];
    try {
      final albums = await PhotoManager.getAssetPathList(
        type: RequestType.video,
        hasAll: true,
      );

      for (final album in albums) {
        final assets = await album.getAssetListRange(
          start: 0,
          end: await album.assetCountAsync,
        );

        for (final asset in assets) {
          final file = await asset.file;
          if (file != null) {
            files.add(FileModel(
              id: asset.id,
              name: asset.title ?? 'Video',
              path: file.path,
              size: await file.length(),
              mimeType: 'video/*',
              category: 'Videos',
              lastModified: asset.modifiedDateTime ?? DateTime.now(),
              isStarred: false,
              isFavorite: false,
              isInVault: false,
            ));
          }
        }
      }
    } catch (e) {
      debugPrint('Error scanning videos: $e');
    }
    return files;
  }

  /// Scan Audio Files
  static Future<List<FileModel>> _scanAudio() async {
    final files = <FileModel>[];
    try {
      final musicDir = Directory('/storage/emulated/0/Music');
      if (await musicDir.exists()) {
        final entities = musicDir.listSync(recursive: true);
        for (final entity in entities) {
          if (entity is File && _isAudioFile(entity.path)) {
            files.add(FileModel(
              id: entity.path.hashCode.toString(),
              name: entity.path.split('/').last,
              path: entity.path,
              size: entity.lengthSync(),
              mimeType: 'audio/*',
              category: 'Audio',
              lastModified: entity.lastModifiedSync(),
              isStarred: false,
              isFavorite: false,
              isInVault: false,
            ));
          }
        }
      }
    } catch (e) {
      debugPrint('Error scanning audio: $e');
    }
    return files;
  }

  /// Scan Documents
  static Future<List<FileModel>> _scanDocuments() async {
    final files = <FileModel>[];
    try {
      final documentsDir = Directory('/storage/emulated/0/Documents');
      if (await documentsDir.exists()) {
        final entities = documentsDir.listSync(recursive: true);
        for (final entity in entities) {
          if (entity is File && _isDocumentFile(entity.path)) {
            files.add(FileModel(
              id: entity.path.hashCode.toString(),
              name: entity.path.split('/').last,
              path: entity.path,
              size: entity.lengthSync(),
              mimeType: 'application/*',
              category: 'Documents',
              lastModified: entity.lastModifiedSync(),
              isStarred: false,
              isFavorite: false,
              isInVault: false,
            ));
          }
        }
      }
    } catch (e) {
      debugPrint('Error scanning documents: $e');
    }
    return files;
  }

  /// Scan PDF Files
  static Future<List<FileModel>> _scanPDFs() async {
    final files = <FileModel>[];
    try {
      final downloadsDir = Directory('/storage/emulated/0/Download');
      if (await downloadsDir.exists()) {
        final entities = downloadsDir.listSync(recursive: true);
        for (final entity in entities) {
          if (entity is File && entity.path.endsWith('.pdf')) {
            files.add(FileModel(
              id: entity.path.hashCode.toString(),
              name: entity.path.split('/').last,
              path: entity.path,
              size: entity.lengthSync(),
              mimeType: 'application/pdf',
              category: 'PDFs',
              lastModified: entity.lastModifiedSync(),
              isStarred: false,
              isFavorite: false,
              isInVault: false,
            ));
          }
        }
      }
    } catch (e) {
      debugPrint('Error scanning PDFs: $e');
    }
    return files;
  }

  /// Scan APK Files
  static Future<List<FileModel>> _scanAPKs() async {
    final files = <FileModel>[];
    try {
      final downloadDir = Directory('/storage/emulated/0/Download');
      if (await downloadDir.exists()) {
        final entities = downloadDir.listSync(recursive: true);
        for (final entity in entities) {
          if (entity is File && entity.path.endsWith('.apk')) {
            files.add(FileModel(
              id: entity.path.hashCode.toString(),
              name: entity.path.split('/').last,
              path: entity.path,
              size: entity.lengthSync(),
              mimeType: 'application/vnd.android.package-archive',
              category: 'APK Files',
              lastModified: entity.lastModifiedSync(),
              isStarred: false,
              isFavorite: false,
              isInVault: false,
            ));
          }
        }
      }
    } catch (e) {
      debugPrint('Error scanning APKs: $e');
    }
    return files;
  }

  /// Scan Archive Files (ZIP, RAR)
  static Future<List<FileModel>> _scanArchives() async {
    final files = <FileModel>[];
    try {
      final downloadDir = Directory('/storage/emulated/0/Download');
      if (await downloadDir.exists()) {
        final entities = downloadDir.listSync(recursive: true);
        for (final entity in entities) {
          if (entity is File && (entity.path.endsWith('.zip') || entity.path.endsWith('.rar'))) {
            files.add(FileModel(
              id: entity.path.hashCode.toString(),
              name: entity.path.split('/').last,
              path: entity.path,
              size: entity.lengthSync(),
              mimeType: 'application/zip',
              category: 'ZIP/RAR',
              lastModified: entity.lastModifiedSync(),
              isStarred: false,
              isFavorite: false,
              isInVault: false,
            ));
          }
        }
      }
    } catch (e) {
      debugPrint('Error scanning archives: $e');
    }
    return files;
  }

  /// Scan E-books
  static Future<List<FileModel>> _scanEBooks() async {
    final files = <FileModel>[];
    try {
      final documentsDir = Directory('/storage/emulated/0/Documents');
      if (await documentsDir.exists()) {
        final entities = documentsDir.listSync(recursive: true);
        for (final entity in entities) {
          if (entity is File && (entity.path.endsWith('.epub') || entity.path.endsWith('.mobi'))) {
            files.add(FileModel(
              id: entity.path.hashCode.toString(),
              name: entity.path.split('/').last,
              path: entity.path,
              size: entity.lengthSync(),
              mimeType: 'application/epub',
              category: 'E-books',
              lastModified: entity.lastModifiedSync(),
              isStarred: false,
              isFavorite: false,
              isInVault: false,
            ));
          }
        }
      }
    } catch (e) {
      debugPrint('Error scanning e-books: $e');
    }
    return files;
  }

  /// Scan WhatsApp Media
  static Future<List<FileModel>> _scanWhatsAppMedia() async {
    final files = <FileModel>[];
    try {
      final whatsappDir = Directory('/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media');
      if (await whatsappDir.exists()) {
        final entities = whatsappDir.listSync(recursive: true);
        for (final entity in entities) {
          if (entity is File) {
            files.add(FileModel(
              id: entity.path.hashCode.toString(),
              name: entity.path.split('/').last,
              path: entity.path,
              size: entity.lengthSync(),
              mimeType: 'media/*',
              category: 'WhatsApp',
              lastModified: entity.lastModifiedSync(),
              isStarred: false,
              isFavorite: false,
              isInVault: false,
            ));
          }
        }
      }
    } catch (e) {
      debugPrint('Error scanning WhatsApp media: $e');
    }
    return files;
  }

  /// Scan Telegram Media
  static Future<List<FileModel>> _scanTelegramMedia() async {
    final files = <FileModel>[];
    try {
      final telegramDir = Directory('/storage/emulated/0/Telegram');
      if (await telegramDir.exists()) {
        final entities = telegramDir.listSync(recursive: true);
        for (final entity in entities) {
          if (entity is File) {
            files.add(FileModel(
              id: entity.path.hashCode.toString(),
              name: entity.path.split('/').last,
              path: entity.path,
              size: entity.lengthSync(),
              mimeType: 'media/*',
              category: 'Telegram',
              lastModified: entity.lastModifiedSync(),
              isStarred: false,
              isFavorite: false,
              isInVault: false,
            ));
          }
        }
      }
    } catch (e) {
      debugPrint('Error scanning Telegram media: $e');
    }
    return files;
  }

  /// Helper: Check if file is audio
  static bool _isAudioFile(String path) {
    final audioExtensions = ['.mp3', '.wav', '.flac', '.aac', '.m4a', '.wma'];
    return audioExtensions.any((ext) => path.toLowerCase().endsWith(ext));
  }

  /// Helper: Check if file is document
  static bool _isDocumentFile(String path) {
    final docExtensions = ['.doc', '.docx', '.txt', '.xls', '.xlsx', '.ppt', '.pptx'];
    return docExtensions.any((ext) => path.toLowerCase().endsWith(ext));
  }

  /// Get recent files (last 30 days)
  Future<List<FileModel>> getRecentFiles({int limit = 50}) async {
    final thirtyDaysAgo = DateTime.now().subtract(const Duration(days: 30));
    final db = await _databaseService.database;

    final results = await db.query(
      'files',
      where: 'lastModified > ?',
      whereArgs: [thirtyDaysAgo.millisecondsSinceEpoch],
      orderBy: 'lastModified DESC',
      limit: limit,
    );

    return results.map((json) => FileModel.fromJson(json)).toList();
  }

  /// Search files by name (with debounce)
  Future<List<FileModel>> searchFiles(String query) async {
    if (query.isEmpty) return [];

    final db = await _databaseService.database;
    final results = await db.query(
      'files',
      where: 'name LIKE ?',
      whereArgs: ['%$query%'],
      limit: 100,
    );

    return results.map((json) => FileModel.fromJson(json)).toList();
  }

  /// Get files by category
  Future<List<FileModel>> getFilesByCategory(String category) async {
    final db = await _databaseService.database;
    final results = await db.query(
      'files',
      where: 'category = ?',
      whereArgs: [category],
      orderBy: 'lastModified DESC',
    );

    return results.map((json) => FileModel.fromJson(json)).toList();
  }

  /// Get category statistics
  Future<Map<String, dynamic>> getCategoryStats(String category) async {
    final db = await _databaseService.database;

    final countResult = await db.rawQuery(
      'SELECT COUNT(*) as count, SUM(size) as totalSize FROM files WHERE category = ?',
      [category],
    );

    if (countResult.isNotEmpty) {
      return {
        'count': countResult.first['count'] ?? 0,
        'totalSize': countResult.first['totalSize'] ?? 0,
      };
    }

    return {'count': 0, 'totalSize': 0};
  }

  /// Cleanup: Remove deleted files from database
  Future<void> cleanupDeletedFiles() async {
    final db = await _databaseService.database;
    final results = await db.query('files');

    for (final row in results) {
      final filePath = row['path'] as String;
      final file = File(filePath);

      if (!await file.exists()) {
        await db.delete('files', where: 'path = ?', whereArgs: [filePath]);
      }
    }
  }

  /// Dispose resources
  void dispose() {
    stopScan();
    _receivePort?.close();
  }
}
