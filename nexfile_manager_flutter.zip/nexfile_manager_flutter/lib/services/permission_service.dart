import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io';

/// PermissionService - Handles Android native permissions
class PermissionService {
  static const String _permissionsKey = 'permissions_requested';

  /// Request initial permissions on app launch
  Future<bool> requestInitialPermissions() async {
    if (!Platform.isAndroid) {
      return true;
    }

    try {
      // Check if permissions were already requested
      if (await _permissionsAlreadyRequested()) {
        return true;
      }

      // Request all necessary permissions
      final statuses = await [
        Permission.storage,
        Permission.manageExternalStorage,
        Permission.camera,
        Permission.microphone,
      ].request();

      // Check if all permissions are granted
      bool allGranted = true;
      statuses.forEach((permission, status) {
        if (!status.isGranted) {
          allGranted = false;
          debugPrint('Permission ${permission.toString()} not granted: $status');
        }
      });

      // Mark permissions as requested
      await _markPermissionsRequested();

      return allGranted;
    } catch (e) {
      debugPrint('Error requesting permissions: $e');
      return false;
    }
  }

  /// Check if storage permission is granted
  Future<bool> hasStoragePermission() async {
    if (!Platform.isAndroid) {
      return true;
    }

    try {
      final status = await Permission.storage.request();
      return status.isGranted;
    } catch (e) {
      debugPrint('Error checking storage permission: $e');
      return false;
    }
  }

  /// Check if manage external storage permission is granted (Android 11+)
  Future<bool> hasManageExternalStoragePermission() async {
    if (!Platform.isAndroid) {
      return true;
    }

    try {
      final status = await Permission.manageExternalStorage.request();
      return status.isGranted;
    } catch (e) {
      debugPrint('Error checking manage external storage permission: $e');
      return false;
    }
  }

  /// Check if camera permission is granted
  Future<bool> hasCameraPermission() async {
    if (!Platform.isAndroid) {
      return true;
    }

    try {
      final status = await Permission.camera.request();
      return status.isGranted;
    } catch (e) {
      debugPrint('Error checking camera permission: $e');
      return false;
    }
  }

  /// Check if microphone permission is granted
  Future<bool> hasMicrophonePermission() async {
    if (!Platform.isAndroid) {
      return true;
    }

    try {
      final status = await Permission.microphone.request();
      return status.isGranted;
    } catch (e) {
      debugPrint('Error checking microphone permission: $e');
      return false;
    }
  }

  /// Request storage permission
  Future<PermissionStatus> requestStoragePermission() async {
    if (!Platform.isAndroid) {
      return PermissionStatus.granted;
    }

    try {
      return await Permission.storage.request();
    } catch (e) {
      debugPrint('Error requesting storage permission: $e');
      return PermissionStatus.denied;
    }
  }

  /// Request camera permission
  Future<PermissionStatus> requestCameraPermission() async {
    if (!Platform.isAndroid) {
      return PermissionStatus.granted;
    }

    try {
      return await Permission.camera.request();
    } catch (e) {
      debugPrint('Error requesting camera permission: $e');
      return PermissionStatus.denied;
    }
  }

  /// Request microphone permission
  Future<PermissionStatus> requestMicrophonePermission() async {
    if (!Platform.isAndroid) {
      return PermissionStatus.granted;
    }

    try {
      return await Permission.microphone.request();
    } catch (e) {
      debugPrint('Error requesting microphone permission: $e');
      return PermissionStatus.denied;
    }
  }

  /// Check if permission is permanently denied
  Future<bool> isPermissionPermanentlyDenied(Permission permission) async {
    try {
      final status = await permission.status;
      return status.isPermanentlyDenied;
    } catch (e) {
      debugPrint('Error checking permission status: $e');
      return false;
    }
  }

  /// Open app settings
  Future<void> openAppSettings() async {
    try {
      await openAppSettings();
    } catch (e) {
      debugPrint('Error opening app settings: $e');
    }
  }

  /// Get all permission statuses
  Future<Map<String, PermissionStatus>> getAllPermissionStatuses() async {
    try {
      final permissions = [
        Permission.storage,
        Permission.manageExternalStorage,
        Permission.camera,
        Permission.microphone,
      ];

      final statuses = <String, PermissionStatus>{};
      for (final permission in permissions) {
        statuses[permission.toString()] = await permission.status;
      }

      return statuses;
    } catch (e) {
      debugPrint('Error getting permission statuses: $e');
      return {};
    }
  }

  /// Helper: Mark permissions as requested
  Future<void> _markPermissionsRequested() async {
    // This would typically be stored in SharedPreferences
    // Implementation depends on your storage strategy
  }

  /// Helper: Check if permissions were already requested
  Future<bool> _permissionsAlreadyRequested() async {
    // This would typically be checked from SharedPreferences
    // Implementation depends on your storage strategy
    return false;
  }
}
