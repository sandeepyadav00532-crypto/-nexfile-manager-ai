# NexFile Manager AI - Build and Deployment Guide

Complete instructions for building and deploying the production-ready Flutter APK.

---

## Prerequisites

Before you begin, ensure you have the following installed:

### 1. Flutter SDK
- **Download:** https://flutter.dev/docs/get-started/install
- **Version:** 3.0.0 or higher
- **Verify Installation:**
  ```bash
  flutter --version
  flutter doctor
  ```

### 2. Android SDK
- **Minimum API Level:** 24 (Android 7.0)
- **Target API Level:** 34 (Android 14)
- **Required Components:**
  - Android SDK Platform 34
  - Android SDK Build-tools 34.0.0
  - Android Emulator (optional, for testing)

### 3. Java Development Kit (JDK)
- **Version:** JDK 11 or higher
- **Verify Installation:**
  ```bash
  java -version
  ```

### 4. Git (Optional)
- For version control and repository management

---

## Project Setup

### Step 1: Extract/Clone Project Files
```bash
# Navigate to your projects directory
cd ~/projects

# Copy all Flutter project files to your local machine
# Ensure the following structure exists:
# nexfile_manager_flutter/
# ├── lib/
# ├── android/
# ├── ios/
# ├── assets/
# ├── pubspec.yaml
# └── README.md
```

### Step 2: Install Dependencies
```bash
cd nexfile_manager_flutter

# Get all Flutter dependencies
flutter pub get

# Generate necessary files (for JSON serialization, etc.)
flutter pub run build_runner build --delete-conflicting-outputs
```

### Step 3: Add Custom Assets
Follow the **ASSET_CONFIGURATION_GUIDE.md** to add your custom images:
- `assets/images/app_logo.png` - Your app logo
- `assets/images/owner_profile.png` - Sandeep Yadav's profile photo

---

## Development Testing

### Run on Emulator
```bash
# Start Android Emulator (if not already running)
emulator -avd Pixel_4_API_34

# Run the app in debug mode
flutter run

# Run with verbose logging
flutter run -v
```

### Run on Physical Device
```bash
# Enable USB Debugging on your Android device
# Connect device via USB

# List connected devices
flutter devices

# Run on device
flutter run -d <device_id>
```

### Hot Reload (During Development)
```bash
# While app is running, press 'r' to hot reload
# Press 'R' to hot restart
# Press 'q' to quit
```

---

## Testing Checklist

Before building the final APK, test the following:

- [ ] **Home Screen**
  - [ ] Search functionality works
  - [ ] Categories display correctly
  - [ ] Recent files load
  - [ ] Storage status bar shows accurate data

- [ ] **Storage Screen**
  - [ ] Storage gauge displays correctly
  - [ ] Category breakdown shows accurate percentages
  - [ ] Cleanup options are accessible

- [ ] **Tools Screen**
  - [ ] All tool categories display
  - [ ] Tool descriptions are visible
  - [ ] Tool selection works

- [ ] **Vault Screen**
  - [ ] Lock screen displays
  - [ ] Unlock methods (Biometric, PIN, Pattern) work
  - [ ] Vault content displays when unlocked

- [ ] **Settings Screen**
  - [ ] Theme selection works (Light, Dark, AMOLED)
  - [ ] Language selection works
  - [ ] Settings persist after app restart

- [ ] **About Screen**
  - [ ] App logo displays correctly
  - [ ] Owner profile photo displays
  - [ ] Owner name "Sandeep Yadav" is visible
  - [ ] 10-tap logo detection works

- [ ] **Admin Panel**
  - [ ] 10 taps on logo in About screen triggers entry
  - [ ] PIN authentication works (default: 7848)
  - [ ] Welcome header displays "Welcome Back, Owner Sandeep Yadav"
  - [ ] Owner profile image displays in header
  - [ ] Feature toggles work
  - [ ] UI customization works

---

## Build APK (Release)

### Step 1: Configure Signing Key

#### Option A: Create New Signing Key
```bash
# Generate a new keystore file
keytool -genkey -v -keystore ~/nexfile_manager.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias nexfile_manager_key

# When prompted, enter:
# - Keystore password: (choose a strong password)
# - Key password: (can be same as keystore)
# - First and Last Name: Sandeep Yadav
# - Organization: NexFile Manager
# - City: (your city)
# - State: (your state)
# - Country Code: IN (for India)
```

#### Option B: Use Existing Keystore
If you already have a keystore file, skip to Step 2.

### Step 2: Configure Android Build

Create or update `android/key.properties`:
```properties
storePassword=YOUR_KEYSTORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=nexfile_manager_key
storeFile=/path/to/nexfile_manager.jks
```

### Step 3: Update Build Configuration

Edit `android/app/build.gradle` and ensure signing config is set:
```gradle
android {
    ...
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile file(keystoreProperties['storeFile'])
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

### Step 4: Build Release APK
```bash
# Navigate to project directory
cd nexfile_manager_flutter

# Build release APK
flutter build apk --release

# Output location:
# build/app/outputs/flutter-apk/app-release.apk
```

### Step 5: Build App Bundle (for Google Play Store)
```bash
# Build App Bundle
flutter build appbundle --release

# Output location:
# build/app/outputs/bundle/release/app-release.aab
```

---

## APK Output

After successful build, you'll find:

### Release APK
- **Location:** `build/app/outputs/flutter-apk/app-release.apk`
- **Size:** ~50-80 MB (depending on included assets)
- **Installation:** Can be installed directly on Android devices

### App Bundle
- **Location:** `build/app/outputs/bundle/release/app-release.aab`
- **Purpose:** For uploading to Google Play Store
- **Size:** ~40-60 MB (compressed)

---

## Installation on Device

### Method 1: Direct APK Installation
```bash
# Connect device via USB
flutter install build/app/outputs/flutter-apk/app-release.apk

# Or use adb directly
adb install build/app/outputs/flutter-apk/app-release.apk
```

### Method 2: Manual Installation
1. Transfer APK to your Android device
2. Open file manager on device
3. Locate the APK file
4. Tap to install
5. Grant necessary permissions

### Method 3: Google Play Store
1. Create Google Play Developer Account ($25 one-time fee)
2. Upload App Bundle (AAB) to Google Play Console
3. Configure app listing, screenshots, description
4. Submit for review
5. App appears on Play Store after approval (24-48 hours)

---

## Troubleshooting Build Issues

### Issue: "Unable to find a matching variant"
**Solution:**
```bash
flutter clean
flutter pub get
flutter build apk --release -v
```

### Issue: "Keystore was tampered with, or password was incorrect"
**Solution:**
1. Verify keystore file path is correct
2. Verify passwords in `key.properties`
3. Regenerate keystore if necessary

### Issue: "Android SDK not found"
**Solution:**
```bash
flutter config --android-sdk /path/to/android/sdk
flutter doctor
```

### Issue: "Build fails with out of memory"
**Solution:**
```bash
# Increase Gradle memory
export GRADLE_OPTS="-Xmx2048m -XX:MaxPermSize=512m"
flutter build apk --release
```

### Issue: "Gradle sync failed"
**Solution:**
```bash
flutter clean
flutter pub get
flutter pub run build_runner build --delete-conflicting-outputs
flutter build apk --release
```

---

## Post-Build Verification

### Verify APK Contents
```bash
# List APK contents
unzip -l build/app/outputs/flutter-apk/app-release.apk

# Check for custom assets
unzip -l build/app/outputs/flutter-apk/app-release.apk | grep "assets/images"
```

### Test APK Installation
```bash
# Install on test device
adb install build/app/outputs/flutter-apk/app-release.apk

# Launch app
adb shell am start -n com.nexfile.manager_ai/.MainActivity

# View logs
adb logcat | grep flutter
```

---

## Performance Optimization

### Reduce APK Size
```bash
# Build with split APKs (one per architecture)
flutter build apk --release --split-per-abi

# Output: app-armeabi-v7a-release.apk, app-arm64-v8a-release.apk
```

### Enable ProGuard/R8 Obfuscation
Edit `android/app/build.gradle`:
```gradle
buildTypes {
    release {
        minifyEnabled true
        shrinkResources true
        proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
    }
}
```

---

## Distribution

### Share APK
1. **Direct Download Link:** Host APK on cloud storage (Google Drive, Dropbox)
2. **GitHub Releases:** Upload to GitHub releases page
3. **Firebase App Distribution:** Use Firebase for beta testing
4. **Google Play Store:** Official distribution channel

### Version Management
- Update `version` in `pubspec.yaml` for each release
- Format: `MAJOR.MINOR.PATCH+BUILD`
- Example: `1.0.0+1` → `1.0.1+2`

---

## Release Checklist

Before final release:

- [ ] All features tested and working
- [ ] Custom logo and owner profile images added
- [ ] Admin panel accessible (10 taps + PIN 7848)
- [ ] Welcome header displays correctly
- [ ] No console errors or warnings
- [ ] APK size acceptable (<100 MB)
- [ ] Signing key configured and backed up
- [ ] Version number updated
- [ ] App name and description finalized
- [ ] Privacy policy and terms prepared
- [ ] Screenshots and promotional images ready

---

## Support & Maintenance

### Update Dependencies
```bash
flutter pub upgrade
flutter pub outdated
```

### Check for Issues
```bash
flutter analyze
flutter test
```

### Monitor Crashes
- Integrate Firebase Crashlytics (already in pubspec.yaml)
- Monitor crashes in Firebase Console

---

## Contact & Support

For issues or questions:
- **Developer:** Sandeep Yadav
- **App:** NexFile Manager AI v1.0.0
- **Build Date:** June 2024

---

**Last Updated:** June 2024
**Status:** Production Ready
