# NexFile Manager AI - Asset Configuration Guide

This guide explains where to place your custom logo and owner profile image files in the Flutter project.

## Project Structure

```
nexfile_manager_flutter/
├── assets/
│   ├── images/
│   │   ├── app_logo.png                    ← YOUR APP LOGO (Replace this)
│   │   ├── app_logo_dark.png               ← APP LOGO DARK MODE (Optional)
│   │   ├── owner_profile.png               ← YOUR OWNER PROFILE PHOTO (Replace this)
│   │   ├── splash_screen.png               ← SPLASH SCREEN (Optional)
│   │   ├── placeholder.png
│   │   ├── no_files.png
│   │   └── error.png
│   ├── icons/
│   ├── animations/
│   └── translations/
├── lib/
│   ├── main.dart
│   ├── screens/
│   │   ├── home_screen.dart
│   │   ├── storage_screen.dart
│   │   ├── tools_screen.dart
│   │   ├── vault_screen.dart
│   │   ├── settings_screen.dart
│   │   ├── admin_panel_screen.dart
│   │   └── about_screen.dart
│   ├── services/
│   ├── controllers/
│   ├── models/
│   ├── providers/
│   └── widgets/
├── android/
│   └── app/
│       └── src/
│           └── main/
│               ├── AndroidManifest.xml
│               └── res/
│                   ├── mipmap-hdpi/
│                   ├── mipmap-mdpi/
│                   ├── mipmap-xhdpi/
│                   ├── mipmap-xxhdpi/
│                   └── mipmap-xxxhdpi/
├── pubspec.yaml
└── ASSET_CONFIGURATION_GUIDE.md
```

---

## Custom Image Files to Replace

### 1. App Logo
**File Path:** `assets/images/app_logo.png`

**Specifications:**
- **Format:** PNG with transparent background
- **Dimensions:** 1024x1024 pixels (minimum)
- **Aspect Ratio:** 1:1 (square)
- **Purpose:** Used as the app launcher icon and in the About screen
- **Recommended:** Your premium 'N'-folder logo design with emerald green accents

**Where It's Used:**
- App launcher icon (Android home screen)
- About screen (top section)
- Splash screen (if enabled)
- App header branding

### 2. App Logo Dark Mode (Optional)
**File Path:** `assets/images/app_logo_dark.png`

**Specifications:**
- **Format:** PNG with transparent background
- **Dimensions:** 1024x1024 pixels (minimum)
- **Aspect Ratio:** 1:1 (square)
- **Purpose:** Dark mode variant of the app logo
- **Optional:** If not provided, the light version will be used

### 3. Owner Profile Photo
**File Path:** `assets/images/owner_profile.png`

**Specifications:**
- **Format:** PNG or JPG
- **Dimensions:** 400x400 pixels (minimum, preferably 600x600)
- **Aspect Ratio:** 1:1 (square, will be displayed as circular)
- **Purpose:** Owner profile picture displayed in:
  - About screen (dedicated owner profile section)
  - Admin panel welcome header (after PIN authentication)
- **Recommended:** Professional headshot or portrait photo of Sandeep Yadav

**Where It's Used:**
- About screen - "App Owner & Developer" section (circular profile)
- Admin panel - Welcome header with greeting "Welcome Back, Owner Sandeep Yadav"
- Bordered with emerald green accent color

### 4. Splash Screen (Optional)
**File Path:** `assets/images/splash_screen.png`

**Specifications:**
- **Format:** PNG
- **Dimensions:** 1080x1920 pixels (for full-screen display)
- **Aspect Ratio:** 9:16 (portrait)
- **Purpose:** Splash screen displayed on app launch
- **Optional:** If not provided, a default splash will be used

---

## How to Add Your Custom Images

### Step 1: Prepare Your Images
1. Ensure your images meet the specifications above
2. Use high-quality images (minimum 400x400 for profile, 1024x1024 for logo)
3. For PNG files, ensure transparent backgrounds where appropriate
4. Name files exactly as specified above

### Step 2: Create Assets Directory (if not exists)
```bash
mkdir -p assets/images
```

### Step 3: Copy Your Images
Place your custom images in the `assets/images/` directory:

```bash
# Copy app logo
cp /path/to/your/logo.png assets/images/app_logo.png

# Copy owner profile
cp /path/to/your/profile_photo.jpg assets/images/owner_profile.png

# Copy splash screen (optional)
cp /path/to/your/splash.png assets/images/splash_screen.png
```

### Step 4: Update pubspec.yaml
The `pubspec.yaml` file is already configured to include these assets:

```yaml
flutter:
  uses-material-design: true
  
  assets:
    # Custom Images - Replace these with your own files
    - assets/images/app_logo.png
    - assets/images/app_logo_dark.png
    - assets/images/owner_profile.png
    - assets/images/splash_screen.png
    
    # Default Assets
    - assets/images/
    - assets/icons/
    - assets/animations/
    - assets/translations/
```

No changes needed here - just ensure your files are in the correct location.

### Step 5: Run the App
```bash
flutter pub get
flutter run
```

---

## Image Usage in Code

### App Logo (About Screen)
**File:** `lib/screens/about_screen.dart`

```dart
Image.asset(
  'assets/images/app_logo.png',
  fit: BoxFit.cover,
  errorBuilder: (context, error, stackTrace) {
    // Fallback if image not found
    return Icon(Icons.folder);
  },
)
```

### Owner Profile (About Screen)
**File:** `lib/screens/about_screen.dart`

```dart
Image.asset(
  'assets/images/owner_profile.png',
  fit: BoxFit.cover,
  errorBuilder: (context, error, stackTrace) {
    // Fallback if image not found
    return Icon(Icons.person);
  },
)
```

### Owner Profile (Admin Panel)
**File:** `lib/screens/admin_panel_screen.dart`

```dart
Image.asset(
  'assets/images/owner_profile.png',
  fit: BoxFit.cover,
  errorBuilder: (context, error, stackTrace) {
    // Fallback if image not found
    return Icon(Icons.person, color: Colors.white);
  },
)
```

---

## Android Icon Configuration

For the app launcher icon, you also need to update Android-specific icon files:

### Icon Locations
```
android/app/src/main/res/
├── mipmap-hdpi/ic_launcher.png          (72x72)
├── mipmap-mdpi/ic_launcher.png          (48x48)
├── mipmap-xhdpi/ic_launcher.png         (96x96)
├── mipmap-xxhdpi/ic_launcher.png        (144x144)
└── mipmap-xxxhdpi/ic_launcher.png       (192x192)
```

### How to Generate Android Icons
You can use Flutter's icon generation tool:

```bash
flutter pub get
flutter pub run flutter_launcher_icons:main
```

Or manually create icons using an online tool:
- [Android Asset Studio](https://romannurik.github.io/AndroidAssetStudio/)
- [App Icon Generator](https://www.appicon.co/)

---

## Troubleshooting

### Image Not Appearing
1. **Check file path:** Ensure the file is in `assets/images/` directory
2. **Check filename:** Must match exactly (case-sensitive on Linux)
3. **Run `flutter pub get`:** After adding new assets, run this command
4. **Clean build:** Run `flutter clean` then `flutter run`

### Image Quality Issues
1. **Use high-resolution source:** Minimum 1024x1024 for logos, 600x600 for profiles
2. **Optimize file size:** Use PNG compression or JPG compression
3. **Check format:** Use PNG for transparency, JPG for photographs

### Asset Not Found Error
```
Error: Unable to load asset: assets/images/app_logo.png
```

**Solution:**
1. Verify file exists in correct directory
2. Run `flutter pub get`
3. Run `flutter clean && flutter run`

---

## Specifications Summary

| File | Path | Format | Size | Aspect | Usage |
|------|------|--------|------|--------|-------|
| App Logo | `assets/images/app_logo.png` | PNG | 1024x1024+ | 1:1 | Launcher, About, Splash |
| App Logo Dark | `assets/images/app_logo_dark.png` | PNG | 1024x1024+ | 1:1 | Dark Mode (Optional) |
| Owner Profile | `assets/images/owner_profile.png` | PNG/JPG | 600x600+ | 1:1 | About, Admin Panel |
| Splash Screen | `assets/images/splash_screen.png` | PNG | 1080x1920 | 9:16 | Launch Screen (Optional) |

---

## Next Steps

1. **Prepare your images** according to the specifications above
2. **Copy them to** `assets/images/` directory
3. **Run** `flutter pub get`
4. **Test the app** with `flutter run`
5. **Build APK** with `flutter build apk --release`

---

## Support

If you encounter any issues with asset loading:
1. Check the error message in the console
2. Verify file names and paths (case-sensitive)
3. Ensure file formats are correct (PNG/JPG)
4. Run `flutter clean && flutter pub get && flutter run`

---

**Last Updated:** June 2024
**Project:** NexFile Manager AI v1.0.0
