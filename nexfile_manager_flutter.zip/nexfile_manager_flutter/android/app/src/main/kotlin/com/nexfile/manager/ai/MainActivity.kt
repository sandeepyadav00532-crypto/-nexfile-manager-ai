package com.nexfile.manager.ai

import io.flutter.embedding.android.FlutterActivity

/**
 * MainActivity - Modern Flutter v2 Embedding
 * 
 * This activity uses the new Flutter embedding which provides:
 * - Better performance
 * - Improved lifecycle management
 * - Full Kotlin support
 * - No deprecated v1 boilerplate
 */
class MainActivity: FlutterActivity() {
    // No additional configuration needed for standard Flutter apps
    // All platform channels and method calls are handled by the Flutter framework
}
